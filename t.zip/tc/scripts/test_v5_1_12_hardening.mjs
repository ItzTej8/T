import assert from "node:assert/strict";
import fs from "node:fs";

const index = fs.readFileSync("src/index.js", "utf8");
const player = fs.readFileSync("src/player.js", "utf8");
const voice = fs.readFileSync("src/voice.js", "utf8");
const ws = fs.readFileSync("src/ws.js", "utf8");
const consoleSrc = fs.readFileSync("src/console.js", "utf8");
const runner = fs.readFileSync("src/command_runner.js", "utf8");

assert.match(index, /wsRecoveryGeneration/);
assert.match(index, /startupVoiceTimer/);
assert.match(index, /const generation = \+\+heartbeatGeneration/);
assert.doesNotMatch(index, /const heartbeatGeneration = \+\+voiceRoomGeneration/);
assert.match(index, /youtubePlayer\.suspendSourceForVoiceLoss/);
assert.match(index, /await voiceManager\.shutdown\(\)/);
assert.match(index, /flushStats\(\)/);
assert.match(index, /flushPro\(\)/);
assert.match(index, /flushAdvanced\(\)/);
assert.doesNotMatch(index, /client\.roomRejoin\(/);
assert.match(player, /suspendSourceForVoiceLoss\(\)/);
assert.match(player, /_sourceSuspendedPlayIds/);
assert.match(voice, /async shutdown\(\)/);
assert.match(ws, /maxReconnectDelayMs/);
assert.match(consoleSrc, /applyFilterChange/);
assert.match(runner, /applyFilterChange/);
console.log("v5.2.0 hardening regression checks: PASS");
