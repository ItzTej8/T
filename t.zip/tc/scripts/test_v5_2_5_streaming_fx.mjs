import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const root = new URL('..', import.meta.url);
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url)));
assert.equal(pkg.version, '5.2.16');
const player = fs.readFileSync(new URL('../src/player.js', import.meta.url), 'utf8');
const voice = fs.readFileSync(new URL('../src/voice.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
const catalog = fs.readFileSync(new URL('../src/command_catalog.js', import.meta.url), 'utf8');

assert.match(player, /ytdlpDirectAudioUrl/);
assert.match(player, /getUrl:\s*true/);
assert.match(player, /directUrl/);
assert.match(index, /publishAudioStream\(stream, playId, \{ seekOffset/);
assert.match(index, /mediaRetryCount < 3/);
assert.match(index, /without disconnecting LiveKit/);
assert.match(voice, /-reconnect/);
assert.match(voice, /-reconnect_streamed/);
assert.match(voice, /-reconnect_on_network_error/);
assert.match(voice, /-reconnect_on_http_error/);
assert.match(voice, /-reconnect_max_retries/);
assert.match(voice, /-rw_timeout/);
assert.match(voice, /jitterSeconds/);
assert.match(voice, /startupSeconds/);
assert.match(voice, /hasFfmpegDsp/);
for (const name of ['chorus','flanger','vibrato','crystalizer','haas','deesser','bassCut']) assert.match(voice, new RegExp(name));
for (const cmd of ['chorus','flanger','vibrato','crystalizer','haas','deesser','basscut','hifi']) assert.match(catalog, new RegExp(cmd));

const checks = [
  ['chorus=0.6:0.9:55:0.4:0.25:2', 'chorus'],
  ['flanger=delay=6:depth=2:regen=0.15:width=60:speed=0.35', 'flanger'],
  ['vibrato=f=5.2:d=0.12', 'vibrato'],
  ['crystalizer=i=2.5', 'crystalizer'],
  ['haas=left_delay=2.5:right_delay=2.5', 'haas'],
  ['deesser=i=0.5:m=0.5:f=0.5:s=o', 'deesser'],
];
for (const [filter, name] of checks) {
  const r = spawnSync('ffmpeg', ['-v','error','-f','lavfi','-i','sine=frequency=440:duration=0.15','-ac','2','-ar','48000','-af',filter,'-f','null','-'], { encoding:'utf8' });
  assert.equal(r.status, 0, `${name} filter failed: ${r.stderr}`);
}
console.log('v5.2.16 streaming stability + FX tests: PASS');

