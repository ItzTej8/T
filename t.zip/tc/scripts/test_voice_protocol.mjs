import assert from 'node:assert/strict';
import fs from 'node:fs';

const index = fs.readFileSync('src/index.js', 'utf8');
const handlers = fs.readFileSync('src/handlers.js', 'utf8');
const voice = fs.readFileSync('src/voice.js', 'utf8');
const ws = fs.readFileSync('src/ws.js', 'utf8');

// join_stream must never enter the LiveKit publisher path.
assert.match(index, /if \(type === "publish_stream" && event\.token && event\.url\)/);
assert.doesNotMatch(index, /type === "stream_exists" && event\.token/);
assert.doesNotMatch(index, /type === "join_stream" \|\| type === "publish_stream"/);

// Server reset/revoke after a failed publish must keep recovery alive.
assert.match(index, /keeping unlimited recovery alive/);
assert.match(index, /voiceRecoveryWanted && !manualVoiceStop/);

// Explicit leave must stop automatic recovery.
assert.match(index, /manualVoiceStop = true;[\s\S]{0,120}voiceRecoveryWanted = false;/);

// Stream tokens must not be printed into normal event logs.
assert.match(handlers, /\["token", "password", "captchaCode", "captchaUrl"\]/);

// A LiveKit network disconnect must release only the dead Room, not dispose
// the global runtime needed by the next automatic join.
assert.match(voice, /room\.disconnect\(\)/);
assert.match(voice, /_nativeCleanupPromise/);
assert.match(voice, /async disconnect\(\) \{/);
assert.match(voice, /async shutdown\(\) \{/);
assert.match(voice, /await dispose\(\)/);

// A TalkInChat WebSocket reconnect must trigger a fresh voice credential flow.
assert.match(index, /WebSocket recovery: resetting stale stream session and requesting fresh credentials/);
assert.match(index, /requestVoiceJoin\(reconnectRoom, true\)/);
assert.match(ws, /this\.scheduleReconnect\(\)/);

console.log('voice protocol regression tests: PASS');
