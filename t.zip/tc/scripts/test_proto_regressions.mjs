import assert from 'node:assert/strict';
import { encode, decode, readVi, decodeFields } from '../src/proto.js';

const roomItem = decode('RoomItem', encode('RoomItem', {
  name: 'hello_!', usersCount: 4, maxUsers: 100,
  membersOnly: true, passwordProtected: false, isVip: true, isStreaming: true
}));
assert.equal(roomItem.membersOnly, true);
assert.equal(roomItem.passwordProtected, false);
assert.equal(roomItem.isVip, true);
assert.equal(roomItem.isStreaming, true);
assert.equal(roomItem.usersCount, 4);

const roomEvent = decode('RoomEvent', encode('RoomEvent', {
  type: 'you_joined', room: 'hello_!', isStreaming: '1', isAgent: '0'
}));
assert.equal(roomEvent.isStreaming, '1');
assert.equal(roomEvent.isAgent, '0');

// Packed repeated int32: field 20 (animation), payload [1,2,127,128].
const packed = Buffer.from([0xA2, 0x01, 0x05, 0x01, 0x02, 0x7F, 0x80, 0x01]);
const repeated = decode('RoomEvent', packed);
assert.deepEqual(repeated.animation, [1, 2, 127, 128]);

// Repeated wire-0 scalar values are retained instead of silently dropping all
// but the first occurrence.
const repeatedWire0 = encode('RoomEvent', { animation: [3, 4, 5] });
assert.deepEqual(decode('RoomEvent', repeatedWire0).animation, [3, 4, 5]);


// Deprecated protobuf groups must not crash the decoder.
// field 50, start-group; nested field 1 varint=7; field 50, end-group.
const grouped = Buffer.from([0x93, 0x03, 0x08, 0x07, 0x94, 0x03]);
const groupFields = decodeFields(grouped);
assert.equal(groupFields[0].fieldNo, 50);
assert.equal(groupFields[0].wire, 3);
assert.equal(groupFields.length, 1);

// A malformed top-level END_GROUP is tolerated as an unknown field so one
// strange packet cannot tear down the long-lived chat socket.
const malformedGroupEnd = Buffer.from([0x94, 0x03]);
assert.doesNotThrow(() => decodeFields(malformedGroupEnd));

console.log('protobuf regression tests: PASS');
