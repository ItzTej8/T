import assert from "node:assert/strict";
import fs from "node:fs";
import { spawnSync } from "node:child_process";

const voice = fs.readFileSync("src/voice.js", "utf8");
const player = fs.readFileSync("src/player.js", "utf8");

assert.match(player, /highest:\s*"bestaudio\/best"/);
assert.match(voice, /const SAMPLE_RATE = 48000/);
assert.match(voice, /const CHANNELS = 2/);
assert.match(voice, /DEFAULT_LIVEKIT_AUDIO_BITRATE = 510000/);
assert.match(voice, /audioEncoding: \{ maxBitrate: requestedAudioBitrate \}/);
assert.match(voice, /optionsForTrack\.red = false/);
assert.match(voice, /optionsForTrack\.dtx = false/);
assert.match(voice, /new AudioSource\(SAMPLE_RATE, CHANNELS, sourceQueueMs\)/);
assert.match(voice, /FRAME_SAMPLES = 480/);
assert.match(voice, /aformat=sample_fmts=s16:sample_rates=48000:channel_layouts=stereo/);
assert.match(voice, /AUDIO_JITTER_BUFFER_SECONDS/);
assert.match(voice, /DEFAULT_PCM_JITTER_SECONDS = 5/);
assert.match(voice, /DEFAULT_PCM_START_BUFFER_SECONDS = 0\.75/);

const r = spawnSync("ffmpeg", [
  "-hide_banner", "-v", "error", "-f", "lavfi",
  "-i", "sine=frequency=440:duration=0.25",
  "-af", "aresample=48000:resampler=soxr:precision=28,aformat=sample_rates=48000:channel_layouts=stereo,aformat=sample_fmts=s16:sample_rates=48000:channel_layouts=stereo",
  "-ar", "48000", "-ac", "2", "-sample_fmt", "s16", "-f", "s16le", "-",
], { encoding: "utf8" });
assert.equal(r.status, 0, r.stderr);
console.log("v5.3.0 audio quality pipeline checks: PASS");
