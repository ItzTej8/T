import assert from 'node:assert/strict';
import fs from 'node:fs';

const player = fs.readFileSync('src/player.js', 'utf8');
const index = fs.readFileSync('src/index.js', 'utf8');
const consoleSrc = fs.readFileSync('src/console.js', 'utf8');
const runner = fs.readFileSync('src/command_runner.js', 'utf8');

assert.match(player, /process\.env\.CHATP_AUDIO_QUALITY \|\| "highest"/);
assert.match(player, /highest: "bestaudio\/best"/);
assert.match(player, /high: "bestaudio\[abr>=192\]\/bestaudio\/best"/);
assert.match(player, /medium: "bestaudio\[abr>=128\]\/bestaudio\/best"/);
assert.match(player, /low: "bestaudio\[abr<=128\]\/bestaudio\/best"/);
assert.match(index, /\.quality \[highest\|high\|medium\|low\]/);
assert.match(index, /applyFilterChange\("audio-quality"/);
assert.match(consoleSrc, /quality \[highest\|high\|medium\|low\]/);
assert.match(runner, /quality \[highest\|high\|medium\|low\]/);
console.log('audio quality v5.2.0 static checks: PASS');
