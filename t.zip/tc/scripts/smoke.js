import { encode, decode } from "../src/proto.js";
import { ACTIONS, ACTIVITIES, INCOMING_EVENTS } from "../src/catalog.js";

const q = encode("Query", {
  action: "room_create",
  room: "test_room",
  value: "test_room",
  password: "",
  intValue: 1
});
console.log("room_create bytes:", q.toString("hex"));
console.log("activities:", ACTIVITIES.length);
console.log("actions:", Object.values(ACTIONS).flat().length);
console.log("incoming catalog:", INCOMING_EVENTS.length);

const a = encode("AuthRequest", {
  type:"login", username:"u", password:"p", sid:"sid",
  sdk:"node", os:"android", ver:"444", clientVer:"1",
  deviceId:"device", deviceModel:"model", language:"en", method:"1"
});
console.log("auth bytes:", a.length);
console.log("decode query:", decode("Query", q));
console.log("OK");
