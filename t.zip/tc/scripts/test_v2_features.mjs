import assert from 'node:assert/strict';
import fs from 'node:fs';
import { getQueueLimit, setQueueLimit, setTransitionSeconds, getTransitionSeconds } from '../src/pro_features.js';
setQueueLimit(123); assert.equal(getQueueLimit(),123);
setTransitionSeconds(7); assert.equal(getTransitionSeconds(),7);
assert.ok(fs.existsSync(new URL('../src/index.js', import.meta.url)));
console.log('v2 feature state tests: PASS');
