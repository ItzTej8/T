import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';

const ffmpeg = process.env.FFMPEG_PATH || 'ffmpeg';
const fx = {
  deep:'asetrate=40000,aresample=48000,atempo=1.2,equalizer=f=180:width_type=h:width=140:g=2',
  helium:'asetrate=57600,aresample=48000,atempo=0.833333,equalizer=f=5000:width_type=h:width=3000:g=1.5',
  demon:'asetrate=36000,aresample=48000,atempo=1.333333,acompressor=threshold=0.18:ratio=3:attack=10:release=120',
  robot:'highpass=f=180,lowpass=f=7000,aphaser=in_gain=0.75:out_gain=0.75:delay=2:decay=0.35:speed=0.7,tremolo=f=18:d=0.12',
  radio:'highpass=f=300,lowpass=f=3400,acompressor=threshold=0.18:ratio=4:attack=5:release=100',
  megaphone:'highpass=f=450,lowpass=f=5000,acompressor=threshold=0.22:ratio=5:attack=3:release=80',
  underwater:'lowpass=f=900,highpass=f=80,aecho=0.7:0.65:35:0.12',
  alien:'asetrate=52800,aresample=48000,atempo=0.909091,aphaser=in_gain=0.7:out_gain=0.8:delay=3:decay=0.5:speed=0.45',
  ghost:'highpass=f=120,lowpass=f=8500,aecho=0.75:0.72:180|360:0.28|0.16,aphaser=in_gain=0.55:out_gain=0.75:delay=2:decay=0.35:speed=0.32',
  cave:'highpass=f=70,lowpass=f=6500,aecho=0.78:0.82:95|190|380:0.32|0.20|0.10',
  space:'highpass=f=90,lowpass=f=10000,aecho=0.72:0.78:120|240|480:0.24|0.16|0.09,extrastereo=m=1.25',
  walkie:'highpass=f=500,lowpass=f=3000,acompressor=threshold=0.16:ratio=5:attack=3:release=90,acrusher=bits=12:mix=0.12',
  vintage:'highpass=f=180,lowpass=f=5200,equalizer=f=900:width_type=h:width=500:g=2,acompressor=threshold=0.2:ratio=3:attack=10:release=150',
  megaphone2:'highpass=f=550,lowpass=f=4200,equalizer=f=1800:width_type=h:width=1400:g=4,acompressor=threshold=0.16:ratio=6:attack=2:release=70,extrastereo=m=1.08',
  child:'asetrate=60000,aresample=48000,atempo=0.8,equalizer=f=3500:width_type=h:width=3000:g=2',
  giant:'asetrate=36000,aresample=48000,atempo=1.333333,equalizer=f=140:width_type=h:width=120:g=3,acompressor=threshold=0.2:ratio=3:attack=10:release=120',
  telephone:'highpass=f=350,lowpass=f=3400,acompressor=threshold=0.18:ratio=4:attack=5:release=100,acrusher=bits=13:mix=0.10',
  underwaterdeep:'highpass=f=55,lowpass=f=650,aecho=0.72:0.70:55|110|220:0.20|0.12|0.07',
  glitch:'highpass=f=140,lowpass=f=9000,acrusher=bits=9:mix=0.28,aphaser=in_gain=0.65:out_gain=0.8:delay=2:decay=0.45:speed=1.6',
  cyber:'highpass=f=100,lowpass=f=9000,aphaser=in_gain=0.65:out_gain=0.82:delay=3:decay=0.5:speed=0.9,tremolo=f=13:d=0.10,extrastereo=m=1.18'
};
assert.equal(Object.keys(fx).length, 20);
for (const [name, filter] of Object.entries(fx)) {
  const r = spawnSync(ffmpeg, ['-hide_banner','-loglevel','error','-f','lavfi','-i','sine=frequency=440:duration=0.6','-af',`${filter},aformat=sample_fmts=s16:sample_rates=48000:channel_layouts=stereo`,'-f','s16le','-y','pipe:1'], {encoding:null});
  assert.equal(r.status, 0, `${name}: FFmpeg failed: ${r.stderr?.toString()}`);
  assert.ok(r.stdout?.length > 1000, `${name}: no PCM output`);
}
console.log('v5.2.16: 20 voice FX FFmpeg self-tests PASS');
