#!/usr/bin/env node
import { spawn } from "node:child_process";
const tests = [
  ["clean", "aresample=resampler=soxr:precision=28"],
  ["pop", "aresample=resampler=soxr:precision=28,equalizer=f=1000:width_type=h:width=200:g=3,equalizer=f=8000:width_type=h:width=1000:g=4"],
  ["rock", "aresample=resampler=soxr:precision=28,equalizer=f=120:width_type=h:width=60:g=4,equalizer=f=3500:width_type=h:width=500:g=3"],
  ["electronic", "aresample=resampler=soxr:precision=28,equalizer=f=60:width_type=h:width=40:g=6,equalizer=f=12000:width_type=h:width=2000:g=4"],
  ["bassboost", "aresample=resampler=soxr:precision=28,equalizer=f=60:width_type=h:width=50:g=8"],
  ["treble", "aresample=resampler=soxr:precision=28,equalizer=f=9000:width_type=h:width=5000:g=6"],
  ["karaoke", "aresample=resampler=soxr:precision=28,pan=stereo|c0=c0-c1|c1=c1-c0"],
  ["reverb", "aresample=resampler=soxr:precision=28,aecho=0.8:0.75:55|110:0.22|0.16"],
  ["wide", "aresample=resampler=soxr:precision=28,extrastereo=m=1.70"],
  ["compressor", "aresample=resampler=soxr:precision=28,acompressor=threshold=0.12:ratio=3:attack=20:release=250:makeup=1.0"],
  ["limiter", "aresample=resampler=soxr:precision=28,alimiter=limit=0.95:attack=5:release=50"],
  ["nightmode", "aresample=resampler=soxr:precision=28,acompressor=threshold=0.12:ratio=3:attack=20:release=250:makeup=1.0,alimiter=limit=0.92:attack=5:release=80"],
  ["normalize", "aresample=resampler=soxr:precision=28,dynaudnorm=f=150:g=7:p=0.9:m=10"],
  ["tremolo", "aresample=resampler=soxr:precision=28,tremolo=f=5.5:d=0.22"],
  ["pitch", "aresample=resampler=soxr:precision=28,asetrate=48000*1.05946309,aresample=48000,atempo=0.94387431"],
  ["speed", "aresample=resampler=soxr:precision=28,atempo=1.25"]
];

function run(name, filter) {
  return new Promise((resolve, reject) => {
    const p = spawn(process.env.FFMPEG_PATH || "ffmpeg", [
      "-hide_banner", "-loglevel", "error",
      "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=0.25",
      "-ac", "2", "-af", filter, "-f", "null", "-"
    ], { stdio: ["ignore", "pipe", "pipe"] });
    let err = "";
    p.stderr.on("data", b => { err += b.toString(); });
    p.on("error", reject);
    p.on("close", code => code === 0 ? resolve() : reject(new Error(`${name}: ${err.trim()}`)));
  });
}

for (const [name, filter] of tests) {
  await run(name, filter);
  console.log(`OK  ${name}`);
}
console.log("Audio filter self-test passed.");
