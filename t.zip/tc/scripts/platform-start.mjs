#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(dirname(fileURLToPath(import.meta.url))));
const bootstrapPath = resolve(root, 'scripts/bootstrap.mjs');
const indexPath = resolve(root, 'src/index.js');
const args = process.argv.slice(2);
const setupOnly = args.includes('--setup-only');
const platformInfo = args.includes('--platform-info');
const isTermux = process.platform === 'android' || !!process.env.TERMUX_VERSION || /\/com\.termux(\/|$)/.test(process.env.PREFIX || '');
const inTermuxProot = process.env.TALKINCHAT_TERMUX_PROOT === '1';

function run(cmd, argv, options = {}) {
  return spawnSync(cmd, argv, { stdio: 'inherit', ...options });
}
function has(cmd) {
  const resolver = process.platform === 'win32' ? 'where.exe' : 'which';
  return spawnSync(resolver, [cmd], { stdio: 'ignore' }).status === 0;
}
function fail(message) { console.error(`\n[Startup] ${message}`); process.exit(1); }

if (platformInfo) {
  console.log(`TalkInChat Music Bot v5.2.16`);
  console.log(`platform=${process.platform}`);
  console.log(`arch=${process.arch}`);
  console.log(`node=${process.version}`);
  console.log(`termux=${isTermux}`);
  console.log(`termuxProot=${inTermuxProot}`);
  console.log(`project=${root}`);
  process.exit(0);
}

// Android/Termux uses Debian proot for the native Linux LiveKit binary.
// @livekit/rtc-node ships Linux x64/arm64 and Windows x64 native packages;
// Android/Bionic is not a matching Node native target, so do not try to load
// the Linux binary directly from native Termux.
if (isTermux && !inTermuxProot) {
  if (!has('proot-distro')) {
    console.log('[Termux] Installing proot-distro...');
    if (run('pkg', ['update', '-y']).status !== 0 || run('pkg', ['install', '-y', 'proot-distro']).status !== 0) {
      fail('Could not install proot-distro. Run: pkg update -y && pkg install -y proot-distro');
    }
  }
  const list = spawnSync('proot-distro', ['list'], { encoding: 'utf8' });
  if (!/debian[^\n]*installed/i.test(list.stdout || '')) {
    console.log('[Termux] Installing Debian (first run only)...');
    if (run('proot-distro', ['install', 'debian']).status !== 0) fail('Could not install Debian.');
  }

  // Bind the actual project directory into Debian. This supports projects in
  // Termux HOME, /storage/emulated/0, or another readable Termux path without
  // copying the project and losing edits.
  const guest = '/mnt/talkinchat-project';
  const inner = [
    'export DEBIAN_FRONTEND=noninteractive',
    'if ! command -v node >/dev/null 2>&1 || [ "$(node -p \"process.versions.node.split(\".\")[0]\")" -lt 18 ]; then',
    '  apt-get update && apt-get install -y ca-certificates curl ffmpeg build-essential python3 make g++;',
    '  if ! command -v node >/dev/null 2>&1 || [ "$(node -p \"process.versions.node.split(\".\")[0]\")" -lt 18 ]; then',
    '    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs;',
    '  fi',
    'else command -v ffmpeg >/dev/null 2>&1 || (apt-get update && apt-get install -y ffmpeg); fi',
    `cd "${guest}"`,
    'npm install --include=optional --no-audit --no-fund --prefer-online',
    'export TALKINCHAT_TERMUX_PROOT=1',
    setupOnly ? 'node scripts/platform-start.mjs --setup-only' : 'node scripts/platform-start.mjs'
  ].join(' && ');

  const bind = `${root}:${guest}`;
  const result = run('proot-distro', ['login', 'debian', '--shared-tmp', '--bind', bind, '--', 'bash', '-lc', inner]);
  process.exit(result.status ?? 1);
}

if (process.platform !== 'win32' && process.platform !== 'linux' && process.platform !== 'darwin') {
  fail(`Unsupported host platform: ${process.platform}. Supported: Windows, Debian/Linux, macOS, or Termux via Debian proot.`);
}

if (!existsSync(bootstrapPath) || !existsSync(indexPath)) fail('Project files are incomplete. Re-extract the full ZIP.');
const boot = run(process.execPath, [bootstrapPath]);
if (boot.status !== 0) process.exit(boot.status ?? 1);
if (setupOnly) { console.log('[Setup] Dependencies and FFmpeg are ready.'); process.exit(0); }
const bot = run(process.execPath, [indexPath], { env: process.env });
process.exit(bot.status ?? 1);
