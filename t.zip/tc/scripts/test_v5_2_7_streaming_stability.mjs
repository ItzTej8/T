import assert from "node:assert/strict";
import fs from "node:fs";
import { spawnSync } from "node:child_process";

const pkg = JSON.parse(fs.readFileSync(new URL("../package.json", import.meta.url), "utf8"));
const voice = fs.readFileSync(new URL("../src/voice.js", import.meta.url), "utf8");
const tui = fs.readFileSync(new URL("../src/tui.js", import.meta.url), "utf8");

assert.equal(pkg.version, "5.2.16");
assert.match(voice, /DEFAULT_PCM_JITTER_SECONDS = 5/);
assert.match(voice, /MAX_PCM_JITTER_SECONDS = 10/);
assert.match(voice, /DEFAULT_PCM_START_BUFFER_SECONDS = 1\.0/);
assert.match(voice, /"-rw_timeout", "8000000"/);
assert.match(voice, /"-reconnect_max_retries", "-1"/);
assert.match(voice, /"-reconnect_on_network_error", "1"/);
assert.match(voice, /"-reconnect_on_http_error", "408,429,500,502,503,504"/);
assert.doesNotMatch(voice, /pending = Buffer\.concat/);
assert.match(voice, /const samples = new Int16Array\(aligned\.buffer\)/);
assert.match(voice, /vol === 1 && fadeSamples === 0/);
assert.match(tui, /setInterval\(\(\)=>setState\(safeState\(context\)\),1200\)/);

const r = spawnSync("ffmpeg", ["-hide_banner", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=0.1", "-f", "s16le", "-ar", "48000", "-ac", "2", "-"], {encoding:"utf8"});
assert.equal(r.status, 0, r.stderr);
console.log("v5.2.16 streaming stability test: PASS");
