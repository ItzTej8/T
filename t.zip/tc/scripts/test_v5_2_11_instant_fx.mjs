import assert from 'node:assert/strict';
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';

const player = fs.readFileSync('src/player.js', 'utf8');
const voice = fs.readFileSync('src/voice.js', 'utf8');
const index = fs.readFileSync('src/index.js', 'utf8');

assert.match(player, /options\.directUrl/);
assert.match(player, /fastStart: true/);
assert.match(voice, /"-i", inputUrl \|\| "pipe:0"/);
assert.match(voice, /\.\.\.\(seekOffset > 0 && inputUrl \? \["-ss", String\(seekOffset\)\] : \[\]\)/);
assert.match(voice, /options\.fastStart/);
assert.match(index, /fastStart: Boolean\(fastStart\)/);
assert.match(index, /case "8dspeed"/);
assert.match(index, /case "treble"/);
assert.match(index, /case "pitch"/);
assert.match(index, /case "limiter"/);
assert.match(index, /case "normalize"/);
assert.match(index, /case "nightmode"/);
assert.match(index, /case "fadein"/);

execFileSync(process.execPath, ['--check', 'src/player.js'], { stdio: 'inherit' });
execFileSync(process.execPath, ['--check', 'src/voice.js'], { stdio: 'inherit' });
execFileSync(process.execPath, ['--check', 'src/index.js'], { stdio: 'inherit' });
console.log('v5.2.16 instant FX/current-position tests: PASS');
