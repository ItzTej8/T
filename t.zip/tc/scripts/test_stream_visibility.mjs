import fs from 'node:fs';
import assert from 'node:assert/strict';

const index = fs.readFileSync('src/index.js', 'utf8');
const voice = fs.readFileSync('src/voice.js', 'utf8');
const client = fs.readFileSync('src/client.js', 'utf8');
const docs = fs.readFileSync('docs/APK_PROTOCOL_NOTES.md', 'utf8');
const ws = fs.readFileSync('src/ws.js', 'utf8');

assert.ok(index.includes('refreshStreamVisibility'), 'must have server Voice/Active visibility synchronization');
assert.ok(!index.includes('client.roomRejoin(targetRoom)'), 'publisher must never rejoin the text room after LiveKit publication');
assert.ok(!index.includes('visibilityRejoinDoneForSession'), 'publisher visibility must not depend on text-room rejoin state');
assert.ok(index.includes('Number(event.isStreaming) === 1'), 'must consume server isStreaming advertisement');
assert.ok(index.includes("await refreshStreamVisibility(effectiveRoom, 'publisher-start')"), 'publisher connection must query Voice/Active server state');
assert.ok(!index.includes('client.publicRooms(0)'), 'must not mistake public_rooms for the APK Voice/Active directory');
assert.ok(index.includes('scheduleVoiceRecovery'), 'must have voice recovery');
assert.ok(!index.includes("recoveryCoordinator.start(reason || 'livekit disconnected')"), 'must not run two independent voice recovery state machines');
assert.ok(index.includes('recoveryAttempt >= 2'), 'stale publisher release must be deferred until a later recovery attempt');
assert.ok(index.includes('setTimeout(tick, 250)'), 'first recovery attempt must start quickly');
assert.ok(index.includes('VOICE_INVITE_TIMEOUT_MS = 15000'), 'publisher invitation timeout must cover the LiveKit handshake window');
assert.ok(index.includes('recoveryResume'), 'must preserve playback recovery state');
assert.ok(index.includes('Connecting immediately'), 'publisher must connect immediately after publish_stream');
assert.ok(index.includes('LIVEKIT_STATIC_CONNECT_DELAY_MS = 0'), 'pre-connect artificial delay must be disabled');
assert.ok(voice.includes('STATIC_LIVEKIT_CONNECT_TIMEOUT_MS = 15000'), 'LiveKit connect timeout must allow slower Termux/mobile handshakes');
assert.ok(voice.includes('STATIC_LIVEKIT_RETRY_DELAY_MS = 5000'), 'LiveKit retry delay must remain 5s');
assert.ok(!voice.match(/await sleep\(500\)/), 'extra post-connect 500ms delay must be removed');
assert.ok(ws.includes('Math.max(10000'), 'ChatP reconnect delay must be at least 10s');
assert.ok(!index.match(/\.9d\b|9d\b/i), '9D command must be absent');
assert.ok(voice.match(/flanger/) && voice.match(/chorus/) && voice.match(/vibrato/), 'new FX filters must be available');
assert.ok(client.includes('roomRejoin(room'), 'client may expose roomRejoin as a low-level legacy API');
assert.ok(client.includes('Do NOT use this after LiveKit publication'), 'roomRejoin documentation must warn against the unstable publisher path');
assert.ok(docs.includes('room_join intValue=1') && docs.includes('isStreaming=1') && docs.includes('connects to LiveKit'), 'APK visibility protocol must be documented');

console.log('stream visibility/reconnect regression checks: PASS');
