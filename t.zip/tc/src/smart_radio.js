import youtubedl from 'youtube-dl-exec';
import { log } from './config.js';

const META_TIMEOUT = Math.max(15000, Number(process.env.YTDLP_META_TIMEOUT_MS || 45000));
const AUDIO_FORMAT = 'bestaudio/best';

function clean(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function words(s) { return new Set(clean(s).toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, ' ').split(/\s+/).filter(x => x.length > 2)); }
function tokenOverlap(a, b) { const A = words(a), B = words(b); if (!A.size || !B.size) return 0; let n=0; for (const x of A) if (B.has(x)) n++; return n / Math.max(1, Math.min(A.size, B.size)); }
function parseEntries(info) {
  const entries = Array.isArray(info?.entries) ? info.entries : [info];
  return entries.filter(e => e?.title).map(e => ({
    title: e.title,
    url: e.webpage_url || e.original_url || (e.id ? `https://www.youtube.com/watch?v=${e.id}` : ''),
    id: e.id || '',
    artist: e.uploader || e.channel || '',
    channel: e.channel || e.uploader || '',
    durationSeconds: Number(e.duration) || 0,
    thumbnail: e.thumbnail || e.thumbnails?.[0]?.url || '',
    categories: Array.isArray(e.categories) ? e.categories : [],
    tags: Array.isArray(e.tags) ? e.tags : [],
    description: clean(e.description || '')
  }));
}
async function search(query, count = 10) {
  const p = youtubedl.exec(`ytsearch${Math.max(1, Math.min(25, count))}:${query}`, {
    dumpSingleJson: true, noWarnings: true, preferFreeFormats: true, format: AUDIO_FORMAT,
    extractorArgs: 'youtube:player_client=android,web'
  });
  let stdout='', stderr='';
  p.stdout?.on('data', d => { stdout += d.toString(); if (stdout.length > 20_000_000) stdout=stdout.slice(-20_000_000); });
  p.stderr?.on('data', d => { stderr += d.toString(); });
  return await new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{try{p.kill('SIGKILL')}catch{} reject(new Error(`Smart Radio search timed out: ${query}`));}, META_TIMEOUT); timer.unref?.();
    p.on('error', e=>{clearTimeout(timer);reject(e)});
    p.on('close', code=>{clearTimeout(timer); if(code!==0)return reject(new Error(stderr.trim()||`yt-dlp exited ${code}`)); try{resolve(parseEntries(JSON.parse(stdout)))}catch(e){reject(e)}});
    p.catch?.(()=>{});
  });
}

function enrich(seed) {
  const title = clean(seed?.title); const artist = clean(seed?.artist);
  const tagText = (seed?.tags || []).slice(0, 20).join(' ');
  const catText = (seed?.categories || []).join(' ');
  const base = [artist, title].filter(Boolean).join(' ');
  return {
    ...seed,
    artist,
    genreHints: clean(`${catText} ${tagText}`),
    moodHints: clean(`${tagText} ${seed?.description || ''}`).slice(0, 700),
    queries: [
      artist ? `${artist} songs` : title,
      artist ? `${artist} similar artists songs` : `${title} similar songs`,
      `${base} similar songs`,
      `${base} recommended songs`,
      seed?.genreHints ? `${seed.genreHints} ${artist} music` : `${artist || title} best songs`,
      seed?.moodHints ? `${seed.moodHints.slice(0,120)} ${artist || title}` : `${artist || title} chill songs`
    ].map(clean).filter(Boolean)
  };
}

export async function discover(seed, { count = 12, recent = [], mode = 'hybrid' } = {}) {
  const s = enrich(seed);
  const recentIds = new Set((recent || []).map(x => String(x?.id || x?.url || '').toLowerCase()).filter(Boolean));
  const recentTitles = (recent || []).map(x => x?.title || '');
  const pool = new Map();
  const modeQueries = mode === 'artist' ? s.queries.slice(0, 2)
    : mode === 'genre' ? [s.genreHints ? `${s.genreHints} ${s.artist} songs` : `${s.artist} genre songs`, ...s.queries.slice(1,3)]
    : mode === 'mood' ? [s.moodHints ? `${s.moodHints.slice(0,180)} ${s.artist} songs` : `${s.artist} mood songs`, ...s.queries.slice(2,4)]
    : mode === 'related' ? [s.artist ? `songs like ${s.artist} ${s.title}` : `${s.title} similar songs`, ...s.queries.slice(1,3)]
    : mode === 'recommended' ? [`${s.artist || s.title} recommended songs`, `${s.artist || s.title} best songs`, ...s.queries.slice(1,3)]
    : s.queries;
  const queryLimit = mode === 'artist' ? 2 : 4;
  for (const q of modeQueries.slice(0, queryLimit)) {
    try { for (const t of await search(q, 8)) { const key=String(t.id||t.url); if(key && !pool.has(key)) pool.set(key,t); } }
    catch (e) { log(`[Smart Radio] query failed: ${q} — ${e.message}`); }
  }
  const candidates = [...pool.values()].filter(t => t.url && !recentIds.has(String(t.id||t.url).toLowerCase()));
  const seedArtist = clean(seed?.artist).toLowerCase();
  const seedTitle = clean(seed?.title);
  candidates.sort((a,b) => score(b,s,seedArtist,seedTitle,recentTitles)-score(a,s,seedArtist,seedTitle,recentTitles));
  return candidates.slice(0, count).map(x => ({...x, requestedBy:'AutoDJ'}));
}
function score(t,s,artist,title,recentTitles) {
  const ta=clean(t.artist).toLowerCase(), tt=clean(t.title);
  let v=0;
  if(artist && ta===artist) v+=35;
  if(artist && ta.includes(artist)) v+=18;
  v += tokenOverlap(tt,title)*10;
  v += tokenOverlap(`${t.categories?.join(' ')} ${t.tags?.join(' ')}`, s.genreHints)*18;
  v += tokenOverlap(`${t.title} ${t.artist} ${t.tags?.join(' ')}`, s.moodHints)*12;
  if (/official|audio|music|topic|vevo/i.test(tt)) v+=3;
  if (/karaoke|cover|nightcore|8d|sped up|slowed|lyrics/i.test(tt)) v-=7;
  if (recentTitles.some(x=>tokenOverlap(x,tt)>0.75)) v-=25;
  v += Math.random()*5;
  return v;
}
