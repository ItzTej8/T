const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function parseVoiceCommand(text) {
  const raw = String(text || '').trim();
  const s = raw.toLowerCase().replace(/[^\p{L}\p{N}\s.:+\-]/gu, ' ').replace(/\s+/g, ' ').trim();
  if (!s) return null;
  const wake = /^(?:hey\s+)?(?:music\s+)?(?:bot|dj)\b\s*/i;
  const command = s.replace(wake, '').trim();
  const rules = [
    [/^(?:pause|stop the music|pause music)$/, 'pause'],
    [/^(?:resume|continue|play music|resume music)$/, 'resume'],
    [/^(?:skip|next|skip song|next song)$/, 'skip'],
    [/^(?:stop|stop music)$/, 'stop'],
    [/^(?:join|join voice|join stream)$/, 'join'],
    [/^(?:leave|leave voice|leave stream)$/, 'leave'],
    [/^(?:reconnect|rejoin|rejoin voice)$/, 'rejoinvoice'],
    [/^(?:what(?:'s| is) playing|now playing|current song)$/, 'nowplaying'],
    [/^(?:queue|show queue|what(?:'s| is) in the queue)$/, 'queue'],
    [/^(?:volume up|louder|increase volume)$/, 'volume +10'],
    [/^(?:volume down|quieter|decrease volume)$/, 'volume -10'],
    [/^volume\s+(\d{1,3})$/, (_,n) => `volume ${clamp(Number(n),0,100)}`],
    [/^(?:mute|mute music)$/, 'mute'],
    [/^(?:unmute|unmute music)$/, 'unmute'],
    [/^(?:8d|8d on|turn on 8d)$/, '8d on'],
    [/^(?:8d off|turn off 8d)$/, '8d off'],
    [/^speed\s+(0\.5|[01](?:\.\d+)?|2(?:\.0)?)$/, (_,n) => `speed ${n}`],
    [/^play\s+(.+)$/, (_,q) => `play ${q}`],
    [/^(?:search|find)\s+(.+)$/, (_,q) => `play ${q}`],
    [/^queue\s+(.+)$/, (_,q) => `qplay ${q}`],
    [/^lyrics(?:\s+(.+))?$/, (_,q) => q ? `lyrics ${q}` : 'lyrics'],
    [/^favorite(?: this)?$/, 'favorite'],
    [/^autoplay\s+(on|off)$/, (_,v) => `autoplay ${v}`],
    [/^247\s+(on|off)$/, (_,v) => `247 ${v}`],
    [/^backup$/, 'backup'],
    [/^(?:health|voice health|voice status)$/, 'voicehealth']
  ];
  for (const [re, out] of rules) {
    const m = command.match(re);
    if (m) return { command: typeof out === 'function' ? out(...m) : out, text: raw };
  }
  return { command: null, text: raw, unsupported: true };
}

