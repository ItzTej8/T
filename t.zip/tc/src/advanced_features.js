import { atomicWriteJson } from './platform_core.js';
import fs from 'node:fs';
import path from 'node:path';
import { dataDir } from './platform_core.js';

const FILE = path.join(dataDir, 'advanced-state.json');
const DEFAULT = {
  audioProfiles: {},
  songSettings: {},
  userProfiles: {},
  radioPresets: {
    hits: 'latest popular music',
    punjabi: 'latest Punjabi songs',
    bollywood: 'latest Bollywood songs',
    lofi: 'lofi chill music',
    edm: 'EDM dance music'
  },
  antiSpam: { enabled: true, windowMs: 5000, maxCommands: 7, strikes: {} },
  vote: { enabled: true, percent: 50, minVotes: 2, durationMs: 30000 },
  schedules: [],
  recentArtists: []
};
function load(){ try { return {...DEFAULT,...JSON.parse(fs.readFileSync(FILE,'utf8'))}; } catch { return structuredClone(DEFAULT); } }
let state=load();
let saveTimer=null; function save(){ if(saveTimer)return; saveTimer=setTimeout(()=>{saveTimer=null;try{atomicWriteJson(FILE,state)}catch{}},200); saveTimer.unref?.(); }
const key=s=>String(s||'').toLowerCase().trim();
export function flushPersistence() { if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; try { atomicWriteJson(FILE, state); } catch {} } }
export function saveAudioProfile(name, filters){ state.audioProfiles[key(name)]={name:String(name),filters:structuredClone(filters)}; save(); return state.audioProfiles[key(name)]; }
export function getAudioProfile(name){ return state.audioProfiles[key(name)]||null; }
export function listAudioProfiles(){ return Object.values(state.audioProfiles); }
export function saveSongSettings(track, settings){ const k=String(track?.url||'').slice(0,1000); if(!k) return null; state.songSettings[k]={...settings,title:track.title||'',url:k}; save(); return state.songSettings[k]; }
export function getSongSettings(track){ return state.songSettings[String(track?.url||'').slice(0,1000)]||null; }
export function setUserProfile(user, patch){ const k=key(user); state.userProfiles[k]={...(state.userProfiles[k]||{}),...patch}; save(); return state.userProfiles[k]; }
export function getUserProfile(user){ return state.userProfiles[key(user)]||{}; }
export function getRadioPresets(){ return structuredClone(state.radioPresets); }
export function saveRadioPreset(name, query){ state.radioPresets[key(name)]=String(query); save(); return String(query); }
export function removeRadioPreset(name){ const k=key(name); if(!state.radioPresets[k]) return false; delete state.radioPresets[k]; save(); return true; }
export function antiSpamCheck(user){
  if(!state.antiSpam.enabled || !user) return {ok:true,strikes:0};
  const k=key(user), now=Date.now(), cur=state.antiSpam.strikes[k]||{times:[],strikes:0,blockedUntil:0};
  cur.times=(cur.times||[]).filter(t=>now-t<state.antiSpam.windowMs);
  if(cur.blockedUntil>now) return {ok:false,remaining:cur.blockedUntil-now,strikes:cur.strikes};
  cur.times.push(now);
  if(cur.times.length>state.antiSpam.maxCommands){ cur.strikes=(cur.strikes||0)+1; cur.times=[]; const cooldown=Math.min(60000,5000*Math.pow(2,cur.strikes-1)); cur.blockedUntil=now+cooldown; }
  state.antiSpam.strikes[k]=cur; save();
  return {ok:cur.blockedUntil<=now,remaining:Math.max(0,cur.blockedUntil-now),strikes:cur.strikes};
}
export function getVoteConfig(){ return structuredClone(state.vote); }
export function setVoteConfig(patch){ state.vote={...state.vote,...patch}; save(); return structuredClone(state.vote); }
export function addSchedule(item){ state.schedules.push(item); save(); return item; }
export function listAdvancedSchedules(){ return structuredClone(state.schedules); }
export function removeSchedule(id){ const n=state.schedules.length; state.schedules=state.schedules.filter(x=>x.id!==id); save(); return n!==state.schedules.length; }
export function updateSchedule(id, patch){ const i=state.schedules.findIndex(x=>x.id===id); if(i<0) return null; state.schedules[i]={...state.schedules[i],...patch}; save(); return structuredClone(state.schedules[i]); }
export function getAdvancedState(){ return structuredClone(state); }
