import {
  Room,
  AudioSource,
  AudioFrame,
  LocalAudioTrack,
  TrackPublishOptions,
  TrackSource,
  dispose
} from "@livekit/rtc-node";
import { EventEmitter } from "node:events";
import { requireFfmpeg } from "./ffmpeg.js";
import { spawn } from "node:child_process";
import { performance } from "node:perf_hooks";
import { log, debug } from "./config.js";

const ffmpegPath = requireFfmpeg();
const SAMPLE_RATE = 48000;
const CHANNELS = 2;
const FRAME_SAMPLES = 480;
const FRAME_BYTES = FRAME_SAMPLES * CHANNELS * 2;
// TalkInChat voice uses a fixed, deterministic LiveKit timing policy.
// Keep connection attempts and retries at exactly 5 seconds instead of
// mixing long SDK/default timeouts with the outer recovery backoff.
const STATIC_LIVEKIT_CONNECT_TIMEOUT_MS = 15000;
const STATIC_LIVEKIT_RETRY_DELAY_MS = 5000;
const DEFAULT_PCM_JITTER_SECONDS = 5;
const DEFAULT_PCM_START_BUFFER_SECONDS = 1.0;
const MIN_PCM_JITTER_SECONDS = 1;
const MAX_PCM_JITTER_SECONDS = 10;
const DEFAULT_LIVEKIT_AUDIO_BITRATE = 510000;
const MIN_LIVEKIT_AUDIO_BITRATE = 64000;
const MAX_LIVEKIT_AUDIO_BITRATE = 510000;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const withTimeout = (promise, ms, label, onTimeout = null) => new Promise((resolve, reject) => {
  let settled = false;
  const timer = setTimeout(() => {
    if (settled) return;
    settled = true;
    try { onTimeout?.(); } catch {}
    reject(new Error(`${label} timed out after ${ms}ms`));
  }, ms);
  Promise.resolve(promise).then(value => {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    resolve(value);
  }, error => {
    if (settled) return;
    settled = true;
    clearTimeout(timer);
    reject(error);
  });
});
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

export class VoiceManager extends EventEmitter {
  constructor() {
    super();
    this.room = null;
    this.audioSource = null;
    this.audioTrack = null;
    this.publication = null;
    this.ffmpeg = null;
    this._activeAudioStream = null;
    this.isConnected = false;
    this.currentRoomName = null;
    this.volume = 1;
    this.lastAudibleVolume = 1;
    this.playbackGeneration = 0;
    this.publishing = false;
    this.captureErrors = 0;
    this._connectPromise = null;
    this._connectionGeneration = 0;
    this._stopping = false;
    this._paused = false;
    this._publishDone = Promise.resolve();
    this._nativeCleanupPromise = Promise.resolve();
    this._spatialPhase = 0;
    this._pcmFramesSent = 0;
    this._lastFrameAt = 0;
    this._pipelineStartedAt = 0;
    this._captureErrorAt = 0;
    this.filters = this.defaultFilters();

    // EventEmitter treats an unhandled `error` event as a process-fatal
    // exception. Voice failures are expected during network recovery, so keep
    // a safe default listener even when VoiceManager is used outside index.js.
    this.on("error", err => {
      log(`[Voice] handled error: ${err?.message || err}`);
    });
  }

  defaultFilters() {
    return {
      preset: "none",
      bassboost: "off",
      treble: 0,
      nightcore: false,
      nightMode: false,
      eightD: false,
      eightDSpeed: 0.11,
      voiceFx: "normal",
      stereoWidth: 0,
      speed: 1.0,
      pitch: 0,
      karaoke: false,
      reverb: false,
      wide: false,
      compressor: false,
      limiter: false,
      normalize: false,
      tremolo: false,
      mono: false,
      echo: false,
      phaser: false,
      lofi: false,
      surround: false,
      fadeIn: false,
      chorus: false,
      flanger: false,
      vibrato: false,
      crystalizer: false,
      haas: false,
      deesser: false,
      bassCut: false
    };
  }

  setPreset(presetName) {
    const p = String(presetName || "").toLowerCase().trim();
    const aliases = { edm: "electronic", flat: "none", off: "none", clear: "none", dance: "electronic", vocal: "vocal", bass: "bass", classical: "classical", pop: "pop", rock: "rock", treble: "treble", vaporwave: "vaporwave", soft: "soft" };
    if (!Object.prototype.hasOwnProperty.call(aliases, p)) return false;
    this.filters.preset = aliases[p];
    this.emit("presetChanged", this.filters.preset);
    this.emit("filtersChanged", this.filters);
    return this.filters.preset;
  }

  setBassBoost(level) {
    const val = String(level).toLowerCase();
    this.filters.bassboost = ["high", "med", "low", "off"].includes(val)
      ? val
      : (!Number.isNaN(Number(val)) ? clamp(Number(val), 0, 12) : "off");
    this.emit("filtersChanged", this.filters);
    return this.filters.bassboost;
  }

  setTreble(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return this.filters.treble;
    this.filters.treble = clamp(n, -12, 12);
    this.emit("filtersChanged", this.filters);
    return this.filters.treble;
  }

  setNightcore(enable) { this.filters.nightcore = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.nightcore; }
  setNightMode(enable) { this.filters.nightMode = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.nightMode; }
  setEightD(enable) { this.filters.eightD = Boolean(enable); if (!enable) this._spatialPhase = 0; this.emit("filtersChanged", this.filters); return this.filters.eightD; }
  setEightDSpeed(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0.03 || n > 2.0) return this.filters.eightDSpeed;
    this.filters.eightDSpeed = n;
    this.emit("filtersChanged", this.filters);
    return n;
  }
  setStereoWidth(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return this.filters.stereoWidth;
    this.filters.stereoWidth = clamp(n, 0, 150);
    this.filters.wide = this.filters.stereoWidth > 0;
    this.emit("filtersChanged", this.filters);
    return this.filters.stereoWidth;
  }
  setSpeed(multiplier) {
    const num = Number(multiplier);
    if (Number.isFinite(num) && num >= 0.5 && num <= 2.0) { this.filters.speed = num; this.emit("filtersChanged", this.filters); }
    return this.filters.speed;
  }
  setPitch(semitones) {
    const n = Number(semitones);
    if (!Number.isFinite(n)) return this.filters.pitch;
    this.filters.pitch = clamp(n, -12, 12);
    this.emit("filtersChanged", this.filters);
    return this.filters.pitch;
  }
  setKaraoke(enable) { this.filters.karaoke = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.karaoke; }
  setReverb(enable) { this.filters.reverb = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.reverb; }
  setWide(enable) { return this.setStereoWidth(enable ? 100 : 0); }
  setCompressor(enable) { this.filters.compressor = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.compressor; }
  setLimiter(enable) { this.filters.limiter = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.limiter; }
  setNormalize(enable) { this.filters.normalize = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.normalize; }
  setTremolo(enable) { this.filters.tremolo = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.tremolo; }
  setMono(enable) { this.filters.mono = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.mono; }
  setEcho(enable) { this.filters.echo = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.echo; }
  setPhaser(enable) { this.filters.phaser = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.phaser; }
  setLofi(enable) { this.filters.lofi = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.lofi; }
  setSurround(enable) { this.filters.surround = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.surround; }
  setFadeIn(enable) { this.filters.fadeIn = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.fadeIn; }
  setChorus(enable) { this.filters.chorus = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.chorus; }
  setFlanger(enable) { this.filters.flanger = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.flanger; }
  setVibrato(enable) { this.filters.vibrato = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.vibrato; }
  setCrystalizer(enable) { this.filters.crystalizer = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.crystalizer; }
  setHaas(enable) { this.filters.haas = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.haas; }
  setDeesser(enable) { this.filters.deesser = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.deesser; }
  setBassCut(enable) { this.filters.bassCut = Boolean(enable); this.emit("filtersChanged", this.filters); return this.filters.bassCut; }

  setVoiceFx(name) {
    const aliases = {
      normal: "normal", clean: "normal", off: "normal", none: "normal",
      deep: "deep", bass: "deep", male: "deep", man: "man",
      lady: "lady", woman: "lady", femalevoice: "lady",
      kidboy: "kidboy", boy: "kidboy", littleboy: "kidboy",
      kidgirl: "kidgirl", girl: "kidgirl", littlegirl: "kidgirl",
      oldman: "oldman", grandpa: "oldman", elderlyman: "oldman",
      oldwoman: "oldwoman", grandma: "oldwoman", elderlywoman: "oldwoman",
      helium: "helium", chipmunk: "helium", high: "helium", female: "helium",
      demon: "demon", monster: "demon", dark: "demon",
      robot: "robot", robotic: "robot",
      radio: "radio", telephone: "radio", phone: "radio",
      megaphone: "megaphone",
      underwater: "underwater", water: "underwater",
      alien: "alien",
      ghost: "ghost", phantom: "ghost", haunted: "ghost",
      cave: "cave", cavern: "cave",
      space: "space", cosmic: "space",
      walkie: "walkie", walkietalkie: "walkie",
      vintage: "vintage", oldradio: "vintage",
      megaphone2: "megaphone2",
      child: "child", kid: "child",
      giant: "giant", giantvoice: "giant",
      telephone: "telephone",
      underwaterdeep: "underwaterdeep",
      glitch: "glitch",
      cyber: "cyber", cyborg: "cyber",
      vinyl: "vinyl", record: "vinyl",
      distorted: "distorted", distortion: "distorted",
      dream: "dream", dreamy: "dream",
      darkhall: "darkhall", hall: "darkhall",
      cavewide: "cavewide", radiofx: "radiofx"
    };
    const key = String(name || "").toLowerCase().trim();
    if (!Object.prototype.hasOwnProperty.call(aliases, key)) return false;
    this.filters.voiceFx = aliases[key];
    this.emit("filtersChanged", this.filters);
    return this.filters.voiceFx;
  }

  clearFilters() {
    const keep = this.filters.speed;
    this.filters = this.defaultFilters();
    this.filters.speed = keep;
    this.emit("filtersChanged", this.filters);
  }

  hasFfmpegDsp() {
    const f = this.filters;
    return Boolean(
      f.preset !== "none" || f.voiceFx !== "normal" || f.bassboost !== "off" || f.treble !== 0 || f.nightcore ||
      f.nightMode || f.pitch !== 0 || f.karaoke || f.reverb || f.echo || f.phaser ||
      f.lofi || f.surround || f.stereoWidth > 0 || f.compressor || f.limiter ||
      f.normalize || f.tremolo || f.mono || f.chorus || f.flanger || f.vibrato ||
      f.crystalizer || f.haas || f.deesser || f.bassCut || f.speed !== 1.0
    );
  }

  buildAudioFilterString() {
    // Always finish with an explicit PCM/stereo format. FFmpeg can otherwise
    // negotiate an intermediate layout/sample format when an effect is active,
    // and implicit conversion is especially easy to get wrong for mono/stereo
    // YouTube sources. LiveKit receives exactly 48 kHz, stereo, signed 16-bit.
    const chain = [
      // Keep the default path extremely cheap. The source is normally already
      // 48 kHz; forcing high-precision SOXR on every song wastes CPU and can
      // starve the 10 ms LiveKit pump on low-power machines. Use SOXR only
      // when actual DSP is enabled.
      this.hasFfmpegDsp() ? "aresample=48000:resampler=soxr:precision=20" : "aresample=48000",
      "aformat=sample_rates=48000:channel_layouts=stereo"
    ];
    const p = this.filters.preset;

    if (p === "pop") chain.push("equalizer=f=1000:width_type=h:width=200:g=3,equalizer=f=8000:width_type=h:width=1000:g=4");
    else if (p === "rock") chain.push("equalizer=f=120:width_type=h:width=60:g=4,equalizer=f=3500:width_type=h:width=500:g=3");
    else if (p === "electronic") chain.push("equalizer=f=60:width_type=h:width=40:g=5,equalizer=f=12000:width_type=h:width=2000:g=4");
    else if (p === "treble") chain.push("equalizer=f=10000:width_type=h:width=3000:g=6");
    else if (p === "vocal") chain.push("highpass=f=90,equalizer=f=2500:width_type=h:width=1800:g=3,equalizer=f=5000:width_type=h:width=2500:g=2");
    else if (p === "bass") chain.push("equalizer=f=70:width_type=h:width=55:g=7");
    else if (p === "classical") chain.push("highpass=f=45,equalizer=f=250:width_type=h:width=180:g=1.5,equalizer=f=9000:width_type=h:width=3000:g=2");
    else if (p === "vaporwave") chain.push("asetrate=48000*0.82,aresample=48000,aecho=0.8:0.88:60:0.4");
    else if (p === "soft") chain.push("lowpass=f=4000");
    else if (p === "club") chain.push("highpass=f=35,equalizer=f=70:width_type=h:width=55:g=5,equalizer=f=2500:width_type=h:width=1200:g=2,equalizer=f=10000:width_type=h:width=3500:g=3");
    else if (p === "headphones") chain.push("extrastereo=m=1.18,haas=left_delay=2:right_delay=2");
    else if (p === "cinema") chain.push("highpass=f=38,equalizer=f=80:width_type=h:width=60:g=3,equalizer=f=2500:width_type=h:width=1500:g=2,equalizer=f=9000:width_type=h:width=3000:g=2");

    // Character/voice presets. These intentionally use inexpensive FFmpeg
    // filters so enabling a voice style does not create the CPU spikes caused
    // by heavyweight spectral processing. They affect the whole program, so
    // vocals change character while music remains intelligible.
    switch (this.filters.voiceFx) {
      case "man":
        chain.push("asetrate=42240,aresample=48000,atempo=1.136364,equalizer=f=160:width_type=h:width=120:g=2");
        break;
      case "lady":
        chain.push("asetrate=55680,aresample=48000,atempo=0.862069,equalizer=f=4200:width_type=h:width=2800:g=1.5");
        break;
      case "kidboy":
        chain.push("asetrate=62400,aresample=48000,atempo=0.769231,equalizer=f=3500:width_type=h:width=2500:g=2");
        break;
      case "kidgirl":
        chain.push("asetrate=67200,aresample=48000,atempo=0.714286,equalizer=f=5000:width_type=h:width=3000:g=2");
        break;
      case "oldman":
        chain.push("asetrate=38400,aresample=48000,atempo=1.25,highpass=f=70,lowpass=f=6500,acompressor=threshold=0.2:ratio=3:attack=10:release=150");
        break;
      case "oldwoman":
        chain.push("asetrate=48000*0.96,aresample=48000,atempo=1.041667,highpass=f=100,lowpass=f=8500,acompressor=threshold=0.2:ratio=3:attack=10:release=140");
        break;
      case "vinyl":
        chain.push("highpass=f=70,lowpass=f=12500,acrusher=bits=15:mix=0.08,aecho=0.55:0.35:35:0.10");
        break;
      case "distorted":
        chain.push("highpass=f=80,lowpass=f=12000,acrusher=bits=8:mix=0.45,acompressor=threshold=0.2:ratio=4:attack=3:release=80");
        break;
      case "dream":
        chain.push("highpass=f=80,lowpass=f=12000,aecho=0.65:0.72:140|280|560:0.20|0.12|0.06,chorus=0.7:0.9:55:0.35:0.25:2");
        break;
      case "darkhall":
        chain.push("highpass=f=55,lowpass=f=9000,aecho=0.8:0.86:180|360|720:0.28|0.18|0.10");
        break;
      case "cavewide":
        chain.push("highpass=f=60,lowpass=f=7500,aecho=0.82:0.9:110|220|440:0.30|0.20|0.10,extrastereo=m=1.2");
        break;
      case "radiofx":
        chain.push("highpass=f=280,lowpass=f=3600,acompressor=threshold=0.16:ratio=5:attack=4:release=90,acrusher=bits=12:mix=0.08");
        break;
      case "deep":
        chain.push("asetrate=40000,aresample=48000,atempo=1.2,equalizer=f=180:width_type=h:width=140:g=2");
        break;
      case "helium":
        chain.push("asetrate=57600,aresample=48000,atempo=0.833333,equalizer=f=5000:width_type=h:width=3000:g=1.5");
        break;
      case "demon":
        chain.push("asetrate=36000,aresample=48000,atempo=1.333333,acompressor=threshold=0.18:ratio=3:attack=10:release=120");
        break;
      case "robot":
        chain.push("highpass=f=180,lowpass=f=7000,aphaser=in_gain=0.75:out_gain=0.75:delay=2:decay=0.35:speed=0.7,tremolo=f=18:d=0.12");
        break;
      case "radio":
        chain.push("highpass=f=300,lowpass=f=3400,acompressor=threshold=0.18:ratio=4:attack=5:release=100");
        break;
      case "megaphone":
        chain.push("highpass=f=450,lowpass=f=5000,acompressor=threshold=0.22:ratio=5:attack=3:release=80");
        break;
      case "underwater":
        chain.push("lowpass=f=900,highpass=f=80,aecho=0.7:0.65:35:0.12");
        break;
      case "alien":
        chain.push("asetrate=52800,aresample=48000,atempo=0.909091,aphaser=in_gain=0.7:out_gain=0.8:delay=3:decay=0.5:speed=0.45");
        break;
      case "ghost":
        chain.push("highpass=f=120,lowpass=f=8500,aecho=0.75:0.72:180|360:0.28|0.16,aphaser=in_gain=0.55:out_gain=0.75:delay=2:decay=0.35:speed=0.32");
        break;
      case "cave":
        chain.push("highpass=f=70,lowpass=f=6500,aecho=0.78:0.82:95|190|380:0.32|0.20|0.10");
        break;
      case "space":
        chain.push("highpass=f=90,lowpass=f=10000,aecho=0.72:0.78:120|240|480:0.24|0.16|0.09,extrastereo=m=1.25");
        break;
      case "walkie":
        chain.push("highpass=f=500,lowpass=f=3000,acompressor=threshold=0.16:ratio=5:attack=3:release=90,acrusher=bits=12:mix=0.12");
        break;
      case "vintage":
        chain.push("highpass=f=180,lowpass=f=5200,equalizer=f=900:width_type=h:width=500:g=2,acompressor=threshold=0.2:ratio=3:attack=10:release=150");
        break;
      case "megaphone2":
        chain.push("highpass=f=550,lowpass=f=4200,equalizer=f=1800:width_type=h:width=1400:g=4,acompressor=threshold=0.16:ratio=6:attack=2:release=70,extrastereo=m=1.08");
        break;
      case "child":
        chain.push("asetrate=60000,aresample=48000,atempo=0.8,equalizer=f=3500:width_type=h:width=3000:g=2");
        break;
      case "giant":
        chain.push("asetrate=36000,aresample=48000,atempo=1.333333,equalizer=f=140:width_type=h:width=120:g=3,acompressor=threshold=0.2:ratio=3:attack=10:release=120");
        break;
      case "telephone":
        chain.push("highpass=f=350,lowpass=f=3400,acompressor=threshold=0.18:ratio=4:attack=5:release=100,acrusher=bits=13:mix=0.10");
        break;
      case "underwaterdeep":
        chain.push("highpass=f=55,lowpass=f=650,aecho=0.72:0.70:55|110|220:0.20|0.12|0.07");
        break;
      case "glitch":
        chain.push("highpass=f=140,lowpass=f=9000,acrusher=bits=9:mix=0.28,aphaser=in_gain=0.65:out_gain=0.8:delay=2:decay=0.45:speed=1.6");
        break;
      case "cyber":
        chain.push("highpass=f=100,lowpass=f=9000,aphaser=in_gain=0.65:out_gain=0.82:delay=3:decay=0.5:speed=0.9,tremolo=f=13:d=0.10,extrastereo=m=1.18");
        break;
    }

    if (this.filters.bassboost !== "off") {
      const gain = this.filters.bassboost === "high" ? 12 : this.filters.bassboost === "med" ? 8 : this.filters.bassboost === "low" ? 4 : Number(this.filters.bassboost);
      if (gain > 0) chain.push(`equalizer=f=60:width_type=h:width=50:g=${clamp(gain, 0, 12)}`);
    }
    if (this.filters.treble !== 0) chain.push(`equalizer=f=9000:width_type=h:width=5000:g=${clamp(this.filters.treble, -12, 12)}`);

    if (this.filters.karaoke) chain.push("pan=stereo|c0=c0-c1|c1=c1-c0");
    if (this.filters.mono) chain.push("pan=stereo|c0=0.5*c0+0.5*c1|c1=0.5*c0+0.5*c1");
    if (this.filters.reverb) chain.push("aecho=0.8:0.75:55|110:0.18|0.12");
    if (this.filters.echo) chain.push("aecho=0.8:0.7:70|140:0.20|0.12");
    if (this.filters.phaser) chain.push("aphaser=in_gain=0.7:out_gain=0.8:delay=2:decay=0.4:speed=0.5");
    if (this.filters.lofi) chain.push("lowpass=f=5000,highpass=f=180,acrusher=bits=10:mix=0.35");
    if (this.filters.surround) chain.push("extrastereo=m=1.35");
    if (this.filters.chorus) chain.push("chorus=0.6:0.9:55:0.4:0.25:2");
    if (this.filters.flanger) chain.push("flanger=delay=6:depth=2:regen=0.15:width=60:speed=0.35");
    if (this.filters.vibrato) chain.push("vibrato=f=5.2:d=0.12");
    if (this.filters.crystalizer) chain.push("crystalizer=i=2.5");
    if (this.filters.haas) chain.push("haas=left_delay=2.5:right_delay=2.5");
    if (this.filters.deesser) chain.push("deesser=i=0.5:m=0.5:f=0.5:s=o");
    if (this.filters.bassCut) chain.push("highpass=f=120");

    if (this.filters.stereoWidth > 0) {
      const m = 1 + (this.filters.stereoWidth / 100) * 0.7;
      chain.push(`extrastereo=m=${m.toFixed(2)}`);
    }
    if (this.filters.compressor || this.filters.nightMode) chain.push("acompressor=threshold=0.12:ratio=3:attack=20:release=250:makeup=1.0");
    if (this.filters.nightMode) chain.push("alimiter=limit=0.92:attack=5:release=80");
    if (this.filters.limiter) chain.push("alimiter=limit=0.95:attack=5:release=50");
    if (this.filters.normalize) chain.push("dynaudnorm=f=150:g=7:p=0.9:m=10");
    // Final safety limiter only when an actual DSP effect is active. Never put
    // a limiter in the clean/default path: even a transparent-looking limiter
    // can change transients and make vocals sound compressed or distorted.
    if (this.hasFfmpegDsp() && !this.filters.limiter && !this.filters.nightMode) {
      chain.push("alimiter=limit=0.97:attack=5:release=80");
    }
    if (this.filters.tremolo) chain.push("tremolo=f=5.5:d=0.22");

    if (this.filters.nightcore) chain.push("asetrate=60000,aresample=48000");
    if (this.filters.pitch !== 0) {
      const factor = Math.pow(2, this.filters.pitch / 12);
      chain.push(`asetrate=48000*${factor.toFixed(8)},aresample=48000,atempo=${(1 / factor).toFixed(8)}`);
    }
    if (this.filters.speed !== 1.0) chain.push(`atempo=${this.filters.speed}`);
    chain.push("aformat=sample_fmts=s16:sample_rates=48000:channel_layouts=stereo");
    return chain.join(",");
  }

  applyEightD(samples) {
    if (!this.filters.eightD) return;
    // True frame-level equal-power panning. The entire stereo program is
    // moved as one image, without channel muting.
    const hz = clamp(Number(this.filters.eightDSpeed) || 0.11, 0.03, 2.0);
    const phaseStep = (Math.PI * 2 * hz) / SAMPLE_RATE;
    const sideKeep = 0.55;
    for (let i = 0; i < samples.length; i += 2) {
      const phase = this._spatialPhase + (i / 2) * phaseStep;
      const pan = (Math.sin(phase) + 1) * 0.5;
      const leftGain = Math.cos(pan * Math.PI * 0.5);
      const rightGain = Math.sin(pan * Math.PI * 0.5);
      const l = samples[i];
      const r = samples[i + 1];
      const mid = (l + r) * 0.5;
      const side = (l - r) * sideKeep;
      samples[i] = clamp(Math.round(mid * leftGain + side), -32768, 32767);
      samples[i + 1] = clamp(Math.round(mid * rightGain - side), -32768, 32767);
    }
    this._spatialPhase = (this._spatialPhase + (samples.length / 2) * phaseStep) % (Math.PI * 2);
  }

  applyFrameVolumeAndFade(samples) {
    const vol = this.volume;
    const frameStart = this._pcmFramesSent * FRAME_SAMPLES;
    const fadeSamples = this.filters.fadeIn ? SAMPLE_RATE * 0.8 : 0;
    // The clean/high-quality path is the common case. Avoid touching every
    // PCM sample when there is no gain/fade to apply; this materially reduces
    // CPU and GC pressure on Termux/low-power devices.
    if (vol === 1 && fadeSamples === 0) {
      this._pcmFramesSent += FRAME_SAMPLES;
      return;
    }
    for (let i = 0; i < samples.length; i++) {
      let gain = vol;
      if (fadeSamples > 0) gain *= clamp((frameStart + i / CHANNELS) / fadeSamples, 0, 1);
      samples[i] = clamp(Math.round(samples[i] * gain), -32768, 32767);
    }
    this._pcmFramesSent += FRAME_SAMPLES;
  }

  getFilterSummary() {
    const active = [];
    if (this.filters.preset !== "none") active.push(`Preset: ${this.filters.preset.toUpperCase()}`);
    if (this.filters.bassboost !== "off") active.push(`Bass: +${this.filters.bassboost === "high" ? 12 : this.filters.bassboost === "med" ? 8 : this.filters.bassboost === "low" ? 4 : this.filters.bassboost}dB`);
    if (this.filters.treble) active.push(`Treble: ${this.filters.treble > 0 ? "+" : ""}${this.filters.treble}dB`);
    if (this.filters.nightcore) active.push("Nightcore: ON");
    if (this.filters.nightMode) active.push("Night: ON");
    if (this.filters.eightD) active.push(`8D: ON @ ${this.filters.eightDSpeed}Hz`);
    if (this.filters.stereoWidth > 0) active.push(`Width: ${this.filters.stereoWidth}%`);
    if (this.filters.pitch) active.push(`Pitch: ${this.filters.pitch > 0 ? "+" : ""}${this.filters.pitch}st`);
    if (this.filters.karaoke) active.push("Karaoke: ON");
    if (this.filters.reverb) active.push("Reverb: ON");
    if (this.filters.compressor) active.push("Compressor: ON");
    if (this.filters.limiter) active.push("Limiter: ON");
    if (this.filters.normalize) active.push("Normalize: ON");
    if (this.filters.tremolo) active.push("Tremolo: ON");
    if (this.filters.mono) active.push("Mono: ON");
    if (this.filters.echo) active.push("Echo: ON");
    if (this.filters.phaser) active.push("Phaser: ON");
    if (this.filters.lofi) active.push("Lo-Fi: ON");
    if (this.filters.surround) active.push("Surround: ON");
    if (this.filters.fadeIn) active.push("Fade-in: ON");
    if (this.filters.chorus) active.push("Chorus: ON");
    if (this.filters.flanger) active.push("Flanger: ON");
    if (this.filters.vibrato) active.push("Vibrato: ON");
    if (this.filters.crystalizer) active.push("Crystalizer: ON");
    if (this.filters.haas) active.push("Haas: ON");
    if (this.filters.deesser) active.push("De-Esser: ON");
    if (this.filters.bassCut) active.push("Bass Cut: ON");
    if (this.filters.speed !== 1.0) active.push(`Speed: ${this.filters.speed}x`);
    if (this.filters.voiceFx !== "normal") active.push(`Voice FX: ${this.filters.voiceFx}`);
    return active.length ? active.join(" | ") : "None (Clean)";
  }

  get isConnecting() { return Boolean(this._connectPromise); }

  async connectToRoom(livekitUrl, token, roomName, options = {}) {
    if (this.isConnected && this.room) return true;
    if (this._connectPromise) return this._connectPromise;
    this._stopping = false;
    this.currentRoomName = roomName;
    this._connectPromise = this._connect(livekitUrl, token, roomName, options);
    try { return await this._connectPromise; } finally { this._connectPromise = null; }
  }

  async _connect(livekitUrl, token, roomName, options = {}) {
    log(`[Voice] Connecting to LiveKit: ${livekitUrl} (room=${roomName})`);
    const connectTimeoutMs = STATIC_LIVEKIT_CONNECT_TIMEOUT_MS;
    const publishTimeoutMs = Math.max(15000, Number(options.publishTimeoutMs || 30000));
    const maxAttempts = Math.max(1, Number(options.maxAttempts || 3));
    let lastError = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      if (this._stopping) return false;
      const attemptGeneration = ++this._connectionGeneration;
      let room = null;
      let source = null;
      let track = null;
      let publication = null;
      let interrupted = false;
      let disconnectedReason = null;

      try {
        if (attemptGeneration !== this._connectionGeneration) return false;
        this._nativeDisconnected = false;
        log(`[Voice] LiveKit attempt ${attempt}/${maxAttempts} ...`);
        room = new Room();
        this.room = room;

        const onDisconnected = reason => {
          if (attemptGeneration !== this._connectionGeneration || this._nativeDisconnected) return;
          disconnectedReason = reason;
          interrupted = true;
          this._nativeDisconnected = true;
          if (this.room === room) {
            this.isConnected = false;
            this.publishing = false;
            this.publication = null;
          }
          log(`[Voice] LiveKit disconnected${reason ? `: ${reason}` : ""}`);
          // Stop the media pump and close native track/source resources as soon
          // as the transport dies. Awaiting cleanup here would delay the
          // EventEmitter notification, so cleanup is kicked off concurrently.
          this.stopPlayback();
          try { this._activeAudioStream?.destroy?.(); } catch {}
          this._activeAudioStream = null;
          this._nativeCleanupPromise = Promise.all([
            this._closeResource(track),
            this._closeResource(source),
            Promise.resolve().then(() => room.disconnect()).catch(() => {})
          ]).then(() => undefined);
          // Release the dead room/session immediately. Do NOT dispose the
          // global LiveKit runtime; the recovery path needs that runtime to
          // create a fresh Room and publish again. This also prevents an old
          // disconnected Room from blocking or leaking into the next join.
          if (this.room === room) {
            this.room = null;
            this.audioTrack = null;
            this.audioSource = null;
            this.publication = null;
          }
          this.emit("disconnected", reason);
        };
        const onReconnecting = () => {
          log(`[Voice] LiveKit reconnecting... room="${roomName}"`);
          this.emit("reconnecting", { roomName });
        };
        const onReconnected = () => {
          log(`[Voice] LiveKit transport reconnected. room="${roomName}"`);
          this.emit("reconnected", { roomName });
        };
        room.on?.("disconnected", onDisconnected);
        room.on?.("reconnecting", onReconnecting);
        room.on?.("reconnected", onReconnected);

        await withTimeout(room.connect(livekitUrl, token, {
          autoSubscribe: true,
          dynacast: false
        }), connectTimeoutMs, "LiveKit connection", () => {
          // Invalidate this attempt immediately. The SDK promise itself cannot
          // be cancelled, so disconnect the Room and ignore any late resolution.
          if (attemptGeneration === this._connectionGeneration) this._connectionGeneration++;
          try { room.disconnect(); } catch {}
        });

        if (attemptGeneration !== this._connectionGeneration) {
          await room.disconnect().catch(() => {});
          return false;
        }
        if (this._stopping) {
          await room.disconnect().catch(() => {});
          return false;
        }

        // Publish immediately after the signal/media connection is established.
        // Do not add an artificial delay here; the caller already has a bounded
        // 15s LiveKit connection handshake timeout.
        if (interrupted) throw new Error(`LiveKit connection interrupted during handshake${disconnectedReason ? ` (reason ${disconnectedReason})` : ""}`);

        const sourceQueueMs = clamp(Number(process.env.LIVEKIT_AUDIO_QUEUE_MS) || 1000, 500, 2000);
        source = new AudioSource(SAMPLE_RATE, CHANNELS, sourceQueueMs);
        track = LocalAudioTrack.createAudioTrack("music", source);

        // IMPORTANT: rtc-node's publish options do NOT use an `audioBitrate`
        // field. Audio bitrate lives inside `audioEncoding.maxBitrate`. The
        // old code silently wrote an unknown JS property, so LiveKit kept its
        // normal voice-oriented encoder settings. That is a real bug for the
        // music path.
        const requestedAudioBitrate = clamp(
          Number(process.env.LIVEKIT_AUDIO_BITRATE) || DEFAULT_LIVEKIT_AUDIO_BITRATE,
          MIN_LIVEKIT_AUDIO_BITRATE,
          MAX_LIVEKIT_AUDIO_BITRATE
        );
        let optionsForTrack;
        try {
          optionsForTrack = new TrackPublishOptions({
            source: TrackSource.SOURCE_MICROPHONE,
            audioEncoding: { maxBitrate: requestedAudioBitrate },
            dtx: false,
            red: false,
            simulcast: false
          });
        } catch {
          // Compatibility fallback for older rtc-node builds.
          optionsForTrack = new TrackPublishOptions();
          optionsForTrack.source = TrackSource.SOURCE_MICROPHONE;
          optionsForTrack.dtx = false;
          optionsForTrack.red = false;
          try { optionsForTrack.audioEncoding = { maxBitrate: requestedAudioBitrate }; } catch {}
        }

        publication = await withTimeout(
          room.localParticipant.publishTrack(track, optionsForTrack),
          publishTimeoutMs,
          "LiveKit track publication",
          () => { try { room.disconnect(); } catch {} }
        );

        if (attemptGeneration !== this._connectionGeneration || interrupted || !publication || room.state === "disconnected") {
          throw new Error(`LiveKit disconnected during track publication${disconnectedReason ? ` (reason ${disconnectedReason})` : ""}`);
        }

        this.room = room;
        this.audioSource = source;
        this.audioTrack = track;
        this.publication = publication;
        this.publishing = true;
        this.isConnected = true;
        this._nativeDisconnected = false;
        this.captureErrors = 0;

        log(`[Voice] LiveKit connected. identity=${room.localParticipant.identity}`);
        log(`[Voice] Audio track published: ${publication?.trackSid || "active"} | ${Math.round(requestedAudioBitrate / 1000)} kbps Opus | stereo | DTX off | RED off`);
        this.emit("connected", { roomName, livekitUrl, publication });
        return true;
      } catch (err) {
        lastError = err;
        if (attemptGeneration !== this._connectionGeneration && this._stopping) return false;
        log(`[Voice] LiveKit connection/publish failed (attempt ${attempt}/${maxAttempts}): ${err?.message || err}`);
        if (this.room === room) {
          this.room = null;
          this.audioTrack = null;
          this.audioSource = null;
          this.publication = null;
          this.publishing = false;
          this.isConnected = false;
        }
        try { if (publication?.trackSid && room?.localParticipant) await room.localParticipant.unpublishTrack(publication.trackSid).catch(() => {}); } catch {}
        await this._closeResource(track);
        await this._closeResource(source);
        try { await room?.disconnect?.(); } catch {}
        await this._nativeCleanupPromise.catch(() => {});
        if (attempt < maxAttempts && !this._stopping) {
          const delay = STATIC_LIVEKIT_RETRY_DELAY_MS;
          log(`[Voice] Waiting ${Math.round(delay / 1000)}s before LiveKit retry...`);
          await sleep(delay);
        }
      }
    }

    this.emit("error", lastError || new Error("Unable to publish LiveKit audio track"));
    return false;
  }

  setVolume(vol) {
    const n = clamp(Number(vol) || 0, 0, 1);
    if (n > 0) this.lastAudibleVolume = n;
    this.volume = n; this.emit("volumeChanged", Math.round(n * 100)); return n;
  }
  mute() { if (this.volume > 0) this.lastAudibleVolume = this.volume; return this.setVolume(0); }
  unmute() { return this.setVolume(this.lastAudibleVolume > 0 ? this.lastAudibleVolume : 1); }

  async publishAudioStream(audioStream, playId = 0, options = {}) {
    if (!audioStream) return false;
    this._lastPublishedPlayId = playId;
    const previousPublish = this._publishDone.catch(() => {});
    const generation = ++this.playbackGeneration;
    this._killCurrentFfmpeg();
    await previousPublish;
    if (!this.isConnected || !this.publishing || !this.audioSource || this._stopping) {
      log("[Voice] Cannot publish audio: LiveKit publisher is not connected.");
      try { audioStream.destroy?.(); } catch {}
      return false;
    }
    this.captureErrors = 0;
    this._spatialPhase = 0;
    this._pcmFramesSent = 0;
    // A new FFmpeg/PCM pipeline must never inherit the previous playback
    // session's frame timestamp. The watchdog uses these markers to avoid
    // tearing down a healthy publisher because of stale state after recovery.
    this._lastFrameAt = 0;
    this._pipelineStartedAt = Date.now();
    const source = this.audioSource;
    const inputUrl = typeof audioStream === "string" ? audioStream : null;
    const seekOffset = Math.max(0, Number(options.seekOffset) || 0);
    const isReadableSource = Boolean(audioStream && typeof audioStream.pipe === "function");
    if (!inputUrl && !isReadableSource) {
      log("[Voice] Invalid audio source supplied to publisher.");
      return false;
    }
    // Use the same explicit output contract for clean and DSP playback. This
    // prevents FFmpeg's automatic format negotiation from changing channel
    // layout/sample format between different YouTube codecs.
    const filterString = this.buildAudioFilterString();
    const ffmpegArgs = [
      "-hide_banner", "-loglevel", "error", "-nostdin",
      "-thread_queue_size", "8192",
      "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_at_eof", "1",
      "-reconnect_on_network_error", "1", "-reconnect_on_http_error", "408,429,500,502,503,504",
      "-reconnect_max_retries", "-1", "-reconnect_delay_max", "3",
      "-multiple_requests", "1", "-rw_timeout", "8000000",
      "-fflags", "+discardcorrupt+genpts",
      "-probesize", "1M", "-analyzeduration", "1M"
    ];
    if (inputUrl) {
      ffmpegArgs.push(
        "-user_agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36",
        "-headers", "Referer: https://www.youtube.com/\r\nOrigin: https://www.youtube.com\r\n"
      );
    }
    ffmpegArgs.push(
      "-i", inputUrl || "pipe:0",
      // Put the seek after the input. This is an accurate output seek for
      // compressed YouTube audio and prevents a settings change from exposing
      // the beginning of the track when the remote source ignores fast input
      // seeking. The already-resolved URL is reused, so this does not require
      // another yt-dlp lookup.
      ...(seekOffset > 0 && inputUrl ? ["-ss", String(seekOffset)] : []),
      "-map", "0:a:0?",
      "-vn", "-sn", "-dn",
      // Keep the format constraints explicit at the filter boundary AND at
      // the raw PCM muxer boundary. This is the safest path for Opus/WebM,
      // AAC/M4A and mono sources.
      "-af", filterString,
      "-ac", String(CHANNELS),
      "-ar", String(SAMPLE_RATE),
      "-sample_fmt", "s16",
      "-f", "s16le",
      "pipe:1"
    );
    const ffmpeg = spawn(ffmpegPath, ffmpegArgs, { windowsHide: true, stdio: [inputUrl ? "ignore" : "pipe", "pipe", "pipe"] });
    this.ffmpeg = ffmpeg;
    this._activeAudioStream = isReadableSource ? audioStream : null;
    log(`[Voice] Audio pipeline started: ${SAMPLE_RATE / 1000}kHz stereo PCM s16le${inputUrl ? " (direct source)" : ""}${this.hasFfmpegDsp() ? " + DSP" : " (clean path)"}`);
    const stale = () => generation !== this.playbackGeneration || !this.isConnected || !this.publishing || this.audioSource !== source || this._stopping;
    let closed = false;
    const stopIfCurrent = () => { if (this.ffmpeg === ffmpeg) this.ffmpeg = null; if (this._activeAudioStream === audioStream) this._activeAudioStream = null; };

    const failPump = (error) => {
      if (this.ffmpeg === ffmpeg) {
        try { ffmpeg.stdin?.destroy(); } catch {}
        try { ffmpeg.kill("SIGKILL"); } catch {}
      }
      return false;
    };

    const pump = async () => {
      // A larger decoded-PCM jitter buffer prevents short YouTube
      // delivery stalls from becoming audible gaps. The producer is allowed
      // to run ahead by up to 12 seconds while the consumer always sends one
      // 10ms LiveKit frame at a time. This is deliberately bounded so a bad
      // source cannot consume unbounded memory.
      const queue = [];
      let queuedBytes = 0;
      const jitterSeconds = clamp(Number(process.env.AUDIO_JITTER_BUFFER_SECONDS) || DEFAULT_PCM_JITTER_SECONDS, MIN_PCM_JITTER_SECONDS, MAX_PCM_JITTER_SECONDS);
      const startupDefault = Number(process.env.AUDIO_START_BUFFER_SECONDS) || DEFAULT_PCM_START_BUFFER_SECONDS;
      const startupSeconds = clamp(Number(options.fastStart ? 0.20 : startupDefault), options.fastStart ? 0.15 : 0.5, 5);
      const MAX_BUFFER_BYTES = FRAME_BYTES * Math.round(jitterSeconds * 100);
      const START_BUFFER_BYTES = Math.min(MAX_BUFFER_BYTES, FRAME_BYTES * Math.round(startupSeconds * 100));
      let producerDone = false;
      let producerError = null;
      let notify = null;
      // Do not Buffer.concat() on every FFmpeg chunk. That creates O(n) copies
      // and frequent garbage collection, which can produce audible timing
      // jitter on Termux. Keep chunks and consume them incrementally.
      const chunks = [];
      let chunkIndex = 0;
      let chunkOffset = 0;
      let pendingBytes = 0;

      const wake = () => { const fn=notify; notify=null; try { fn?.(); } catch {} };
      const waitForData = () => new Promise(resolve => { notify=resolve; });
      const enqueueFrames = () => {
        while (pendingBytes >= FRAME_BYTES && queuedBytes + FRAME_BYTES <= MAX_BUFFER_BYTES) {
          const first = chunks[chunkIndex];
          const available = first ? first.length - chunkOffset : 0;
          if (available >= FRAME_BYTES) {
            queue.push(first.subarray(chunkOffset, chunkOffset + FRAME_BYTES));
            chunkOffset += FRAME_BYTES;
            pendingBytes -= FRAME_BYTES;
            queuedBytes += FRAME_BYTES;
            if (chunkOffset >= first.length) { chunks[chunkIndex] = null; chunkIndex++; chunkOffset = 0; }
          } else {
            const frame = Buffer.allocUnsafe(FRAME_BYTES);
            let copied = 0;
            while (copied < FRAME_BYTES && chunkIndex < chunks.length) {
              const c = chunks[chunkIndex];
              const take = Math.min(c.length - chunkOffset, FRAME_BYTES - copied);
              c.copy(frame, copied, chunkOffset, chunkOffset + take);
              copied += take; chunkOffset += take;
              if (chunkOffset >= c.length) { chunks[chunkIndex] = null; chunkIndex++; chunkOffset = 0; }
            }
            if (copied !== FRAME_BYTES) break;
            pendingBytes -= FRAME_BYTES;
            queuedBytes += FRAME_BYTES;
            queue.push(frame);
          }
        }
        // Periodically compact consumed chunk references so the array itself
        // cannot grow for very long tracks.
        if (chunkIndex > 256 && chunkIndex > chunks.length / 2) {
          chunks.splice(0, chunkIndex);
          chunkIndex = 0;
        }
      };

      const producer = (async () => {
        try {
          for await (const chunk of ffmpeg.stdout) {
            if (stale()) break;
            const b = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
            if (b.length) { chunks.push(b); pendingBytes += b.length; }
            enqueueFrames();
            wake();
            while (!stale() && queuedBytes + FRAME_BYTES > MAX_BUFFER_BYTES) {
              await sleep(5);
              enqueueFrames();
            }
          }
          enqueueFrames();
        } catch (err) {
          producerError = err;
        } finally {
          producerDone = true;
          wake();
        }
      })();

      // Do not begin transmission until the initial jitter buffer is filled,
      // unless the source ends first. This prevents immediate start/stop
      // bursts from a slow mobile connection.
      while (!stale() && queuedBytes < START_BUFFER_BYTES && !producerDone) {
        await waitForData();
      }

      let nextFrameAt = performance.now();
      try {
        while (!stale()) {
          if (this._paused) {
            await sleep(20);
            nextFrameAt = performance.now();
            continue;
          }
          if (!queue.length) {
            if (producerDone) break;
            await waitForData();
            continue;
          }

          const waitMs = nextFrameAt - performance.now();
          if (waitMs > 0) await sleep(waitMs);
          if (stale()) break;

          const bytes = queue.shift();
          queuedBytes -= FRAME_BYTES;
          // FFmpeg's s16le stream is exactly 960 interleaved samples per 10 ms
          // frame. Node on our supported Windows/Linux/Android targets is
          // little-endian, so an aligned Int16Array is zero-copy and preserves
          // the PCM values exactly. For an unaligned Buffer, copy the bytes to
          // an aligned ArrayBuffer instead of constructing a view with an
          // unrelated backing-store length.
          // Give the native FFI a standalone, correctly-sized Int16 buffer.
          // Do not hand it a Buffer view whose backing store can contain
          // unrelated bytes or later be pooled/reused by Node. LiveKit's Node
          // documentation explicitly warns about unsafe Buffer conversions.
          const aligned = new Uint8Array(FRAME_BYTES);
          aligned.set(bytes);
          const samples = new Int16Array(aligned.buffer);
          this.applyEightD(samples);
          this.applyFrameVolumeAndFade(samples);
          try {
            // Advance the realtime deadline from the frame timeline, not from
            // the completion time of captureFrame(). This prevents a slow native
            // call from causing a burst of back-to-back frames (which sounds like
            // clicks/static on the receiver).
            nextFrameAt += 10;
            await source.captureFrame(new AudioFrame(samples, SAMPLE_RATE, CHANNELS, FRAME_SAMPLES));
            this._pcmFramesSent++;
            this._lastFrameAt = Date.now();
            if (this._pcmFramesSent % (FRAME_SAMPLES * 100) === 0) this.emit("audioProgress", { playId, at: Date.now() });
            if (nextFrameAt < performance.now() - 15) nextFrameAt = performance.now() + 2;
          } catch (err) {
            const msg = String(err?.message || err);
            if (stale()) break;
            this.captureErrors++; this._captureErrorAt = Date.now();
            log(`[Voice] captureFrame error #${this.captureErrors}: ${msg}`);
            if (/InvalidState|capture frame failed|source.*closed|closed.*source/i.test(msg) || this.captureErrors >= 5) return failPump(err);
            nextFrameAt = performance.now() + 10;
          }
          wake();
        }
        await producer;
        if (producerError && !stale()) {
          log(`[Voice] PCM producer error: ${producerError.message || producerError}`);
          return failPump(producerError);
        }
        return !stale();
      } catch (err) {
        if (!stale()) { log(`[Voice] PCM pump error: ${err?.message || err}`); return failPump(err); }
        return false;
      }
    };

    const pumpPromise = pump();
    this._publishDone = pumpPromise.catch(() => false).then(() => undefined);
    // ChildProcess stdio streams can be null on some spawn/failure paths.
    // Never let diagnostic listeners turn a recoverable media failure into
    // `Cannot read properties of null (reading 'on')`.
    if (ffmpeg.stderr && typeof ffmpeg.stderr.on === "function") {
      ffmpeg.stderr.on("data", data => { const msg = data.toString().trim(); if (msg) debug("[Voice ffmpeg]", msg); });
    }
    if (typeof ffmpeg.on === "function") {
      ffmpeg.on("error", err => { if (!stale()) { log(`[Voice] FFmpeg error: ${err.message}`); this.emit("playbackError", { playId, error: err }); } });
    }
    if (ffmpeg.stdin && typeof ffmpeg.stdin.on === "function") {
      ffmpeg.stdin.on("error", () => {});
    }
    if (audioStream && typeof audioStream.on === "function") {
      audioStream.on("error", err => { if (!stale()) log(`[Voice] YouTube source error: ${err?.message || err}`); });
    }
    ffmpeg.on("close", async code => {
      const ok = await pumpPromise;
      stopIfCurrent();
      if (closed) return;
      closed = true;
      if (!stale() && code === 0 && ok !== false) this.emit("streamFinished", { playId });
      else if (!stale() && ok === false) this.emit("playbackError", { playId, error: new Error("PCM audio pump stopped before FFmpeg completed") });
      else if (!stale() && code !== 0) this.emit("playbackError", { playId, error: new Error(`FFmpeg exited with code ${code}`) });
    });
    if (isReadableSource) {
      audioStream.pipe(ffmpeg.stdin);
    }
    return true;
  }

  getVoiceParticipants() {
    const room = this.room;
    if (!room) return [];
    const out = [];
    try {
      const values = room.remoteParticipants?.values?.() || [];
      for (const p of values) {
        out.push({ identity: p.identity || p.sid || "unknown", name: p.name || p.identity || "unknown", sid: p.sid || null });
      }
    } catch {}
    return out;
  }

  getHealth() {
    return {
      connected: this.isConnected, publishing: this.publishing, room: this.currentRoomName,
      track: !!this.audioTrack, source: !!this.audioSource, publication: !!this.publication,
      ffmpeg: !!this.ffmpeg, lastFrameAt: this._lastFrameAt, framesSent: this._pcmFramesSent,
      captureErrors: this.captureErrors, captureErrorAt: this._captureErrorAt, paused: this._paused, pipelineStartedAt: this._pipelineStartedAt,
      jitterBufferSeconds: clamp(Number(process.env.AUDIO_JITTER_BUFFER_SECONDS) || DEFAULT_PCM_JITTER_SECONDS, MIN_PCM_JITTER_SECONDS, MAX_PCM_JITTER_SECONDS), livekitAudioBitrate: clamp(Number(process.env.LIVEKIT_AUDIO_BITRATE) || DEFAULT_LIVEKIT_AUDIO_BITRATE, MIN_LIVEKIT_AUDIO_BITRATE, MAX_LIVEKIT_AUDIO_BITRATE), directSource: Boolean(this._activeAudioStream === null)
    };
  }
  getFilters() { return structuredClone(this.filters); }
  setFilters(filters = {}) { this.filters = { ...this.defaultFilters(), ...structuredClone(filters) }; this.emit("filtersChanged", this.filters); return this.getFilters(); }

  get isPausedForPlayback() { return this._paused; }
  setPlaybackPaused(value) { this._paused = Boolean(value); }
  _killCurrentFfmpeg() { const stream = this._activeAudioStream; this._activeAudioStream = null; try { stream?.destroy?.(); } catch {} const p = this.ffmpeg; this.ffmpeg = null; if (!p) return; try { p.stdin?.destroy(); } catch {} try { p.stdout?.destroy(); } catch {} try { p.stderr?.destroy(); } catch {} try { p.kill("SIGKILL"); } catch {} }
  stopPlayback({ silent = true } = {}) { this.playbackGeneration++; this._killCurrentFfmpeg(); this._paused = false; this._spatialPhase = 0; this._pcmFramesSent = 0; this._lastFrameAt = 0; this._pipelineStartedAt = 0; if (!silent) this.emit("playbackStopped"); return this._publishDone; }

  async _closeResource(resource) {
    if (!resource?.close) return;
    try { await resource.close(); } catch {}
  }

  async _cleanupLiveKit(disconnect = true) {
    this._stopping = true;
    this.stopPlayback();
    await this._nativeCleanupPromise.catch(() => {});
    const room = this.room;
    const publication = this.publication;
    const track = this.audioTrack;
    const source = this.audioSource;
    await this._publishDone.catch(() => {});
    this.publication = null;
    this.audioTrack = null;
    this.audioSource = null;
    this.publishing = false;
    this.isConnected = false;
    try {
      if (publication?.trackSid && room?.localParticipant) {
        await room.localParticipant.unpublishTrack(publication.trackSid).catch(() => {});
      }
    } catch {}
    // Native rtc-node close operations may return Promises. Await them so a
    // fast recovery cannot race the old native audio source/track cleanup.
    await this._closeResource(track);
    await this._closeResource(source);
    if (disconnect) {
      try { await room?.disconnect?.(); } catch {}
      if (this.room === room) this.room = null;
    }
  }
  async unpublishAudio() { await this._cleanupLiveKit(false); }
  async waitForCleanup() { await this._nativeCleanupPromise.catch(() => {}); await this._publishDone.catch(() => {}); }
  // Disconnect only the current room/session. Do NOT call the global LiveKit
  // `dispose()` here: the Node SDK documents dispose() as a final process-level
  // cleanup for when no more sessions are expected. Calling it on every `.leave`
  // permanently tears down native resources and can make the next `.join` fail.
  async disconnect() {
    await this._cleanupLiveKit(true);
    this.room = null;
    this.currentRoomName = null;
    this._stopping = false;
    this._connectPromise = null;
    log("[Voice] Disconnected from LiveKit voice room (native LiveKit runtime kept alive).");
  }

  // Call only when the bot process is shutting down permanently.
  async shutdown() {
    await this._cleanupLiveKit(true);
    this.room = null;
    this.currentRoomName = null;
    this._stopping = true;
    try { await dispose(); } catch {}
    log("[Voice] LiveKit runtime disposed for process shutdown.");
  }
}
