import crypto from "node:crypto";
import { EventEmitter } from "node:events";
import { encode } from "./proto.js";
import { debug } from "./config.js";

export class ChatPClient extends EventEmitter {
  constructor(socket) {
    super();
    this.socket = socket;
    this.handlers = socket.handlers;
    this.socket.on("message", x => this.emit("message", x));
    this.socket.on("connected", () => this.emit("connected"));
    this.socket.on("reconnect", () => this.emit("reconnect"));
  }

  sendQuery(query) {
    const bytes = encode("Query", query);
    debug("[QUERY]", query);
    this.socket.send(bytes);
    return bytes;
  }

  raw(buffer) { this.socket.send(Buffer.from(buffer)); return Buffer.from(buffer); }
  reconnect() { this.socket.close(4000, "reconnect"); }
  ping() { this.socket.ws?.ping(); }

  // Rooms
  roomCreate(name, isPrivate = false) {
    const room = String(name).trim().replace(/\s+/g, "_");
    if (room.length < 2) throw new Error("Room name must be 2+ characters");
    return this.sendQuery({ action:"room_create", room, value:room, password:"", intValue:isPrivate ? 1 : 0 });
  }
  roomJoin(room, password = "", intValue = 0) {
    const r = String(room ?? "").trim();
    if (!r) throw new Error("Room name cannot be empty");
    const refresh = Number(intValue) === 1 ? 1 : 0;
    return this.sendQuery({action:"room_join", room:r, password, intValue:refresh});
  }
  // Low-level legacy helper only. Do NOT use this after LiveKit publication:
  // on the current server it can trigger a room membership refresh that revokes
  // the publisher. The stable voice path stays on room_join(intValue=0) and
  // waits for the server's official isStreaming/stream_enabled advertisement.
  roomRejoin(room, password = "") { return this.roomJoin(room, password, 1); }
  joinRoom(room, password = "") { return this.roomJoin(room, password, 0); }
  roomJoinCaptcha(room, captchaCode, captchaUrl) { return this.sendQuery({action:"room_join_captcha", room, captchaCode, captchaUrl}); }
  roomLeave(room) {
    const r = String(room ?? "").trim();
    if (!r) return;
    return this.sendQuery({action:"room_leave", room:r});
  }
  leaveRoom(room) { return this.roomLeave(room); }

  roomInfo(type, {page=0, room="", value="", value1=""}={}) {
    return this.sendQuery({action:"room_info", type, intValue:page, room, value, value1});
  }
  publicRooms(page=0) { return this.roomInfo("public_rooms", {page}); }
  trendingRooms() { return this.roomInfo("trending_rooms"); }
  favouriteRooms() { return this.roomInfo("favourite_rooms"); }
  searchRooms(q) {
    if (String(q).length < 3) throw new Error("Search requires 3+ characters");
    return this.roomInfo("search_rooms", {room:String(q)});
  }
  roomValue(room) { return this.roomInfo("room_value", {room}); }
  userValue(username) { return this.roomInfo("user_value", {room:username}); }
  addFavourite(room) { return this.roomInfo("add_favourite", {room}); }
  removeFavourite(room) { return this.roomInfo("remove_favourite", {room}); }

  // Room administration
  roomAdmin(type, room, {to="username", value="none", value1=""}={}) {
    return this.sendQuery({action:"room_admin", type, room, to, value, value1});
  }
  adminList(room, listName) { return this.roomAdmin(String(listName), room); }
  occupants(room) { return this.roomAdmin("occupants_list", room); }
  admins(room) { return this.roomAdmin("admins_list", room); }
  members(room) { return this.roomAdmin("members_list", room); }
  owners(room) { return this.roomAdmin("owners_list", room); }
  outcasts(room) { return this.roomAdmin("outcast_list", room); }
  roomLogs(room) { return this.roomAdmin("room_logs", room); }
  roomSettings(room) { return this.roomAdmin("room_settings", room); }
  resetIp(room) { return this.roomAdmin("reset_ip", room); }
  resetRoom(room) { return this.roomAdmin("reset_room", room, {to:"username", value:"owner"}); }
  kick(room, username) { return this.roomAdmin("kick", room, {to:username, value:"none"}); }
  banIp(room, username) { return this.roomAdmin("ban_ip", room, {to:username, value:"outcast"}); }
  changeRole(room, username, role) {
    if (!["none","member","admin","owner","outcast"].includes(role)) throw new Error("invalid role");
    return this.roomAdmin("change_role", room, {to:username, value:role});
  }

  // Chat
  sendText(to, body, uid=crypto.randomUUID()) { return this.sendQuery({action:"chat_message",type:"text",to,body,uid}); }
  // RoomActivity in the supplied APK uses room_message for messages sent to a room.
  sendRoomText(room, body) { return this.sendQuery({action:"room_message",type:"text",room,body}); }
  sendImage(to, url, uid=crypto.randomUUID()) { return this.sendQuery({action:"chat_message",type:"image",to,url,uid}); }
  sendAudio(to, url, length, uid=crypto.randomUUID()) { return this.sendQuery({action:"chat_message",type:"audio",to,url,value:String(length),uid}); }
  chatState(to, state) { return this.sendQuery({action:"chat_message",type:"state",to,state}); }
  typing(to) { return this.chatState(to, "writing"); }
  typingPaused(to) { return this.chatState(to, "paused"); }
  delivered(to, uid) { return this.sendQuery({action:"chat_message",type:"delivery",to,uid}); }
  seen(to, uid) { return this.sendQuery({action:"chat_message",type:"seen",to,uid}); }
  okMessage(uid) { return this.sendQuery({action:"ok_msg",uid}); }
  sendTextCommand(to, body, uid=crypto.randomUUID()) { return this.sendText(to, body, uid); }
  sendRawBytes(buffer) { return this.raw(buffer); }

  // Profiles/settings
  myProfile() { return this.sendQuery({action:"profile_mine"}); }
  otherProfile(username) { return this.sendQuery({action:"profile_other",type:username,uid:random20()}); }
  profileUpdate(type, value) { return this.sendQuery({action:"profile_update",type,value:String(value)}); }
  setGender(v) { return this.profileUpdate("gender",v); }
  setAllowPM(v) { return this.profileUpdate("allow_pm",v ? "1":"0"); }
  setAllowInvites(v) { return this.profileUpdate("allow_invites",v ? "1":"0"); }
  setVisibility(v) { return this.profileUpdate("set_visibility",v); }
  setAutoJoinStream(v) { return this.profileUpdate("auto_join_stream",v ? "1":"0"); }
  setCalls(v) { return this.profileUpdate("calls",v ? "1":"0"); }
  setEmail(v) { return this.profileUpdate("email",v); }
  setCountry(v) { return this.profileUpdate("country",v); }
  setBirthdate(v) { return this.profileUpdate("birthdate",v); }
  setPhoto(v) { return this.profileUpdate("photo",v); }
  setPassword(v) { return this.profileUpdate("password",v); }

  friendRequest(username) { return this.profileUpdate("send_friend_request",username); }
  friendRequests() { return this.profileUpdate("send_requests",""); }
  acceptFriend(username) { return this.profileUpdate("accept_friend_request",username); }
  rejectFriend(username) { return this.profileUpdate("reject_friend_request",username); }
  removeFriend(username) { return this.profileUpdate("remove_friend",username); }

  blockedList() { return this.sendQuery({action:"blocked_list"}); }
  block(username) { return this.profileUpdate("block",username); }
  unblock(username) { return this.profileUpdate("unblock",username); }
  sessions() { return this.sendQuery({action:"sessions_log"}); }
  lastActivity(username) { return this.sendQuery({action:"last_activity",type:username}); }

  // Streaming
  streamCheck(room) { return this.sendQuery({action:"room_stream",type:"check_is_streaming",room}); }
  streamPublish(room, password="") { return this.sendQuery({action:"room_stream",type:"publish",to:password,room}); }
  requestPublishStream(room, password="") { return this.streamPublish(room, password); }
  streamUnpublish(room, username) { return this.sendQuery({action:"room_stream",type:"unpublish",to:username,room}); }
  streamInvite(room, username) { return this.sendQuery({action:"room_stream",type:"invite",to:username,room}); }
  streamJoin(room, sessionId="") { return this.sendQuery({action:"room_stream",type:"join_stream",room,value:sessionId}); }
  streamStop(room) { return this.sendQuery({action:"room_stream",type:"stop_stream",room}); }

  // Gifts/store
  gifts(type="new_gifts") { return this.sendQuery({action:"gifts",type}); }
  giftsList() { return this.gifts("gifts_list"); }
  giftsListNew() { return this.gifts("gifts_list_new"); }
  publicGifts() { return this.gifts("public_gifts"); }
  sendGift({gift, room, to, value="", value1="", uid=""}={}) {
    return this.sendQuery({action:"gifts",type:"send_gift",id:gift,room,to,value,value1,uid});
  }
  storeData() { return this.sendQuery({action:"store",type:"store_data"}); }
  removeColor() { return this.sendQuery({action:"store",type:"remove_color"}); }
  store(type, fields={}) { return this.sendQuery({action:"store",type,...fields}); }
  upgradeStreaming(room, duration) {
    const d=String(duration);
    if(!["1","7","30"].includes(d)) throw new Error("duration must be 1, 7 or 30");
    return this.sendQuery({action:"store",type:"upgrade_streaming",room,value:d});
  }
  consumePurchase(fields={}) { return this.sendQuery({action:"store",type:"consume_purchase",...fields}); }
  purchase(fields={}) { return this.sendQuery({action:"store",type:"purchase",...fields}); }
  transactions() { return this.sendQuery({action:"store",type:"transactions_list"}); }
  colors() { return this.sendQuery({action:"store",type:"colors_list"}); }

  // Calls
  newCall(peer) { return this.sendQuery({action:"call_handler_new",type:"new_call",to:peer}); }
  joinCall(peer, room, url="", token="") { return this.sendQuery({action:"call_handler_new",type:"join_call",to:peer,room,url,token}); }
  callInfo(peer, value="") { return this.sendQuery({action:"call_handler_new",type:"info",to:peer,value}); }
  endCall(room, peer, duration, username) {
    return this.sendQuery({action:"end_call",to:peer,value:String(duration),value1:username,room});
  }

  // Account / utility
  idSetup(value) { return this.sendQuery({action:"id_setup",type:"set",value:String(value)}); }
  reportAbuse(type, username, details="") { return this.sendQuery({action:"report_abuse",type,to:username,value1:details}); }
  removeAccount() { return this.sendQuery({action:"profile_update",type:"remove_account",value:"1"}); }

  // Generic protocol
  query(action, type, fields={}) { return this.sendQuery({action,type,...fields}); }
}

function random20() {
  const chars="abcdefghijklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
  return Array.from({length:20},()=>chars[Math.floor(Math.random()*chars.length)]).join("");
}
