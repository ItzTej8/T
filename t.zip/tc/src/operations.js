/*
 * Explicit operation wrappers. Keeping these in one file makes it easy to
 * inspect exactly what the Node client sends.
 */

export const operations = {
  roomCreate: (room, isPrivate=false) => ({
    action:"room_create", room, value:room, password:"", intValue:isPrivate ? 1 : 0
  }),
  roomJoin: (room, password="") => ({
    action:"room_join", password, room, intValue:0
  }),
  roomJoinCaptcha: (room, captchaCode, captchaUrl) => ({
    action:"room_join_captcha", room, captchaCode, captchaUrl
  }),
  roomLeave: room => ({action:"room_leave", room}),
  streamPublish: (room, password="") => ({action:"room_stream",type:"publish",to:password,room}),
  streamCheck: room => ({action:"room_stream",type:"check_is_streaming",room}),
  streamInvite: (room,to) => ({action:"room_stream",type:"invite",to,room}),
  streamUnpublish: (room,to) => ({action:"room_stream",type:"unpublish",to,room}),
  newCall: to => ({action:"call_handler_new",type:"new_call",to}),
  endCall: (room,to,duration,value1) => ({action:"end_call",to,value:String(duration),value1,room}),
  okMsg: uid => ({action:"ok_msg",uid})
};

export function allOperationNames() {
  return Object.keys(operations);
}
