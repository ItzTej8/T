import { AtomicStore } from './platform_core.js';
const s=new AtomicStore('community',{users:{},achievements:{}});
const ensure=u=>s.data.users[u] ||= {points:0,plays:0,commands:0,favorites:0,badges:[]};
export function reward(user,points=1){if(!user)return;const x=ensure(user);x.points+=Number(points)||0;return x;}
export function recordPlay(user){if(!user)return;const x=ensure(user);x.plays++;reward(user,2);if(x.plays>=10&&!x.badges.includes('10-plays'))x.badges.push('10-plays');s.save();}
export function recordCommand(user){if(!user)return;ensure(user).commands++;s.save();}
export function leaderboard(n=10){return Object.entries(s.data.users).map(([user,v])=>({user,...v})).sort((a,b)=>b.points-a.points).slice(0,n);}
export function profile(user){return user?ensure(user):null;}
export function addFavoriteBadge(user){if(!user)return;const x=ensure(user);x.favorites++;s.save();}
export function achievements(user){return profile(user)?.badges||[];}
