import fs from "node:fs";
import path from "node:path";
import { log as prettyLog, debug as prettyDebug, setDebugEnabled as setLoggerDebugEnabled } from "./logger.js";

if (typeof process.loadEnvFile === "function") {
  try { process.loadEnvFile(); } catch {}
} else {
  try {
    const envPath = path.resolve(process.cwd(), ".env");
    if (fs.existsSync(envPath)) {
      const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith("#")) continue;
        const eqIdx = trimmed.indexOf("=");
        if (eqIdx > 0) {
          const key = trimmed.slice(0, eqIdx).trim();
          const val = trimmed.slice(eqIdx + 1).trim();
          if (!(key in process.env)) process.env[key] = val;
        }
      }
    }
  } catch {}
}

const env = process.env;

export const config = {
  username: env.CHATP_USERNAME || "",
  password: env.CHATP_PASSWORD || "",
  defaultRoom: env.DEFAULT_ROOM || "sweety",
  authUrl: env.CHATP_AUTH_URL || "https://chatp.net",
  serverPort: env.CHATP_SERVER_PORT || "5335",
  action: env.CHATP_ACTION || "",
  method: env.CHATP_METHOD || "",
  captchaCode: env.CHATP_CAPTCHA_CODE || "",
  captchaUrl: env.CHATP_CAPTCHA_URL || "",
  language: env.CHATP_LANGUAGE || "en",
  apiVer: env.CHATP_API_VER || "2",
  clientVer: env.CHATP_CLIENT_VER || "2",
  ver: env.CHATP_VER || "444",
  sdk: env.CHATP_SDK || "35",
  deviceId: env.CHATP_DEVICE_ID || "a1b2c3d4e5f67890",
  deviceModel: env.CHATP_DEVICE_MODEL || "444$Google-Pixel_6$33",
  pingIntervalMs: Number(env.CHATP_PING_INTERVAL_MS || 30000),
  reconnect: env.CHATP_RECONNECT !== "false",
  reconnectDelayMs: Number(env.CHATP_RECONNECT_DELAY_MS || 10000),
  maxReconnectDelayMs: Number(env.CHATP_MAX_RECONNECT_DELAY_MS || 10000),
  audioQuality: String(env.CHATP_AUDIO_QUALITY || "highest").toLowerCase(),
  debug: env.CHATP_DEBUG === "true"
};

setLoggerDebugEnabled(config.debug);

export function log(...args) {
  prettyLog(...args);
}

export function debug(...args) {
  if (config.debug) prettyDebug(...args);
}
