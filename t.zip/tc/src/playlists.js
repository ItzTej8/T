import fs from "node:fs";
import path from "node:path";
import { log, debug } from "./config.js";
import { atomicWriteJson } from "./platform_core.js";

const PLAYLISTS_FILE = path.resolve(process.cwd(), ".playlists.json");

/**
 * Load all saved playlists from disk
 */
export function loadPlaylists() {
  try {
    if (fs.existsSync(PLAYLISTS_FILE)) {
      const content = fs.readFileSync(PLAYLISTS_FILE, "utf8");
      return JSON.parse(content);
    }
  } catch (err) {
    debug("[Playlists Load Error]", err.message);
  }
  return {};
}

/**
 * Save playlists object to disk
 */
export function savePlaylists(playlists) {
  try {
    atomicWriteJson(PLAYLISTS_FILE, playlists);
    return true;
  } catch (err) {
    log(`[Playlists Save Error] ${err.message}`);
    return false;
  }
}

/**
 * Save a named playlist
 */
export function saveCustomPlaylist(name, tracks, savedBy = "User") {
  const cleanName = String(name || "").trim().toLowerCase().replace(/\s+/g, "_");
  if (!cleanName) throw new Error("Playlist name cannot be empty");
  if (!Array.isArray(tracks) || tracks.length === 0) throw new Error("Cannot save empty playlist");

  const playlists = loadPlaylists();
  playlists[cleanName] = {
    name: cleanName,
    savedBy,
    savedAt: Date.now(),
    trackCount: tracks.length,
    tracks: tracks.map(t => ({
      title: t.title,
      url: t.url,
      duration: t.duration,
      durationSeconds: t.durationSeconds,
      artist: t.artist,
      thumbnail: t.thumbnail
    }))
  };

  savePlaylists(playlists);
  return playlists[cleanName];
}

/**
 * Add one track to an existing custom playlist. If the playlist does not
 * exist, create it automatically with that track. Returns the playlist and
 * whether the track was newly added.
 */
export function addTrackToCustomPlaylist(name, track, savedBy = "User") {
  const cleanName = String(name || "").trim().toLowerCase().replace(/\s+/g, "_");
  if (!cleanName) throw new Error("Playlist name cannot be empty");
  if (!track || !track.title) throw new Error("Invalid track");

  const playlists = loadPlaylists();
  if (!playlists[cleanName]) {
    playlists[cleanName] = {
      name: cleanName,
      savedBy,
      savedAt: Date.now(),
      trackCount: 0,
      tracks: []
    };
  }

  const playlist = playlists[cleanName];
  const exists = playlist.tracks.some(t =>
    (track.url && t.url === track.url) ||
    (!track.url && t.title === track.title)
  );
  if (exists) {
    return { playlist, added: false, count: playlist.tracks.length };
  }

  playlist.tracks.push({
    title: track.title,
    url: track.url,
    duration: track.duration,
    durationSeconds: track.durationSeconds,
    artist: track.artist || "YouTube",
    thumbnail: track.thumbnail || ""
  });
  playlist.trackCount = playlist.tracks.length;
  playlist.updatedAt = Date.now();
  savePlaylists(playlists);
  return { playlist, added: true, count: playlist.tracks.length };
}

/**
 * Get a saved playlist by name
 */
export function getCustomPlaylist(name) {
  const cleanName = String(name || "").trim().toLowerCase().replace(/\s+/g, "_");
  const playlists = loadPlaylists();
  return playlists[cleanName] || null;
}

/**
 * Delete a saved playlist
 */
export function updateCustomPlaylistByIndex(index, updater) {
  const playlists = loadPlaylists();
  const list = Object.values(playlists);
  const i = Number(index) - 1;
  if (!Number.isInteger(i) || i < 0 || i >= list.length) return false;
  const current = list[i];
  const cleanName = current.name;
  const next = updater({ ...current, tracks: current.tracks.map(t => ({ ...t })) });
  if (!next) return false;
  next.trackCount = next.tracks.length;
  next.updatedAt = Date.now();
  delete playlists[cleanName];
  const finalName = String(next.name || cleanName).trim().toLowerCase().replace(/\s+/g, '_');
  next.name = finalName;
  playlists[finalName] = next;
  savePlaylists(playlists);
  return next;
}

export function getCustomPlaylistByIndex(index) {
  const list = listCustomPlaylists();
  const i = Number(index) - 1;
  return Number.isInteger(i) && i >= 0 && i < list.length ? list[i] : null;
}

export function deleteCustomPlaylist(name) {
  const cleanName = String(name || "").trim().toLowerCase().replace(/\s+/g, "_");
  const playlists = loadPlaylists();
  if (!playlists[cleanName]) return false;
  delete playlists[cleanName];
  savePlaylists(playlists);
  return true;
}

/**
 * List all saved playlist names with summaries
 */
export function listCustomPlaylists() {
  const playlists = loadPlaylists();
  return Object.values(playlists);
}
