import { EventEmitter } from "node:events";
import { decode } from "./proto.js";
import { debug, log } from "./config.js";
import { eventCatalog } from "./events.js";

export class ProtocolHandlers extends EventEmitter {
  constructor() {
    super();
    this.catalog = eventCatalog();
  }

  handle(data, isBinary = true) {
    const bytes = Buffer.from(data);
    if (bytes.length > 0 && bytes[0] === 0x7b) {
      try {
        const json = JSON.parse(bytes.toString("utf8"));
        this.emit("json", json);
        if (json.handler) this.emit(`handler:${json.handler}`, json);
        if (json.handlerId !== undefined && json.handlerId !== null) this.emit(`handler:${json.handlerId}`, json);
        if (json.result) this.emit(`result:${json.result}`, json);
        if (json.type) this.emit(json.type, json);

        // Some deployments/proxies can expose nested events as JSON instead of
        // the protobuf ResultMessage used by the Android client. Normalize them
        // to the same event names so the voice path works in both cases.
        if (json.streamEvent) {
          this.emit("streamEvent", json.streamEvent);
          if (json.streamEvent.type) {
            this.emit(`stream:${json.streamEvent.type}`, json.streamEvent);
            this.emit(json.streamEvent.type, json.streamEvent);
          }
        }
        if (json.roomEvent) {
          this.emit("roomEvent", json.roomEvent);
          if (json.roomEvent.type) {
            this.emit(`room:${json.roomEvent.type}`, json.roomEvent);
            this.emit(json.roomEvent.type, json.roomEvent);
          }
        }
        debug("[RESULT JSON]", json);
        return json;
      } catch (err) {
        this.emit("raw", { bytes, error: err });
        return { raw: bytes, error: err };
      }
    }

    let decoded;
    try {
      decoded = decode("ResultMessage", bytes);
    } catch (err) {
      this.emit("raw", { bytes, error: err });
      return { raw: bytes, error: err };
    }

    this.emit("result", decoded);

    if (decoded.type) this.emit(decoded.type, decoded);

    if (decoded.handlerId) {
      this.emit(`handler:${decoded.handlerId}`, decoded);
    }
    if (decoded.roomEvent) {
      this.emit("roomEvent", decoded.roomEvent);
      if (decoded.roomEvent.type) {
        this.emit(decoded.roomEvent.type, decoded.roomEvent);
        this.emit(`room:${decoded.roomEvent.type}`, decoded.roomEvent);
      }
    }
    if (decoded.chatMessage) {
      this.emit("chatMessage", decoded.chatMessage);
      if (decoded.chatMessage.type) {
        this.emit(`chat:${decoded.chatMessage.type}`, decoded.chatMessage);
      }
    }
    if (decoded.streamEvent) {
      this.emit("streamEvent", decoded.streamEvent);
      if (decoded.streamEvent.type) {
        this.emit(`stream:${decoded.streamEvent.type}`, decoded.streamEvent);
        this.emit(decoded.streamEvent.type, decoded.streamEvent);
      }
    }
    if (decoded.callInfo?.action) {
      this.emit(`call:${decoded.callInfo.action}`, decoded.callInfo);
    }

    debug("[RESULT]", JSON.stringify(safe(decoded)));
    return decoded;
  }
}

function safe(value) {
  return JSON.parse(JSON.stringify(value, (key, v) => {
    if (["token", "password", "captchaCode", "captchaUrl"].includes(String(key))) return "[REDACTED]";
    return typeof v === "bigint" ? v.toString() : v;
  }));
}

export function attachDefaultHandlers(client) {
  const names = [
    "room_full", "room_needs_password", "room_wrong_password",
    "room_needs_captcha", "room_unauthorized", "room_membership_required",
    "room_create_exists", "room_create_empty_balance", "room_boost_empty_balance",
    "user_joined", "user_left", "you_joined", "you_rejoined",
    "role_changed", "your_role_changed", "subject_changed",
    "publish_stream", "stream_exists", "stop_stream",
    "stream_enabled", "stop_streaming_service", "sent_invitation",
    "you_invited", "revoked", "gift_new", "boost_room",
    "chat_message", "chat_state", "new_messages", "update_message_status",
    "ack_msg", "new_call", "join_call", "call_started", "update_call_status",
    "ringing", "ready", "busy", "answer", "hang", "end",
    "new_balance", "transactions_list", "purchase_validated"
  ];
  for (const n of names) client.handlers.on(n, payload => debug(`[EVENT:${n}]`, safe(payload)));
}
