import fs from 'node:fs';
import path from 'node:path';
import { EventEmitter } from 'node:events';

const DATA = path.resolve(process.env.BOT_DATA_DIR || '.bot-data');
fs.mkdirSync(DATA,{recursive:true});
export const atomicWriteJson=(file,data)=>{
  const dir=path.dirname(file);
  fs.mkdirSync(dir,{recursive:true});
  const tmp=path.join(dir,`.${path.basename(file)}.tmp-${process.pid}-${Math.random().toString(36).slice(2)}`);
  const fd=fs.openSync(tmp,'w');
  try {
    fs.writeFileSync(fd,JSON.stringify(data,null,2),'utf8');
    try { fs.fsyncSync(fd); } catch {}
  } finally { try { fs.closeSync(fd); } catch {} }
  fs.renameSync(tmp,file);
};
const atomicWrite=atomicWriteJson;
export class AtomicStore {
  constructor(name, initial={}) { this.file=path.join(DATA,name+'.json'); this.data=this.load(initial); }
  load(initial){ try{return {...initial,...JSON.parse(fs.readFileSync(this.file,'utf8'))};}catch{return structuredClone(initial);} }
  save(){atomicWrite(this.file,this.data);}
  patch(p){Object.assign(this.data,p);this.save();return this.data;}
}
export class HookBus extends EventEmitter {
  async run(name,payload={}) { const results=[]; for(const fn of this.listeners(name)){ results.push(await fn(payload)); } return results; }
}
export const hooks=new HookBus();
export const dataDir=DATA;
export function nowIso(){return new Date().toISOString();}
export function safeFileName(s){return String(s).replace(/[^a-z0-9._-]+/gi,'_').slice(0,120);}
export function backupData(label='manual'){
  const dir=path.join(DATA,'backups');fs.mkdirSync(dir,{recursive:true});
  const out=path.join(dir,`${new Date().toISOString().replace(/[:.]/g,'-')}-${safeFileName(label)}.json`);
  const files=fs.readdirSync(DATA).filter(f=>f.endsWith('.json')&&f!=='recovery-journal.json');
  const snapshot={createdAt:nowIso(),files:{}}; for(const f of files){try{snapshot.files[f]=JSON.parse(fs.readFileSync(path.join(DATA,f),'utf8'));}catch{}}
  atomicWrite(out,snapshot); return out;
}
export class SessionGuard {
 constructor(){this.generation=0;this.current=null;}
 start(meta={}){this.generation++;this.current={id:`${Date.now()}-${this.generation}`,generation:this.generation,...meta};return this.current;}
 isCurrent(id){return !!this.current&&this.current.id===id;}
 invalidate(){this.generation++;this.current=null;}
}
export class RecoveryJournal {
 constructor(){this.store=new AtomicStore('recovery-journal',{events:[]});}
 add(event){this.store.data.events.push({at:nowIso(),...event});if(this.store.data.events.length>500)this.store.data.events.shift();this.store.save();}
 recent(n=20){return this.store.data.events.slice(-n);}
}
export function createBackupScheduler(time='00:00',fn=()=>{}){
 let timer=null; const schedule=()=>{const [h,m]=String(time).split(':').map(Number);const now=new Date(), next=new Date(now);next.setHours(h||0,m||0,0,0);if(next<=now)next.setDate(next.getDate()+1);timer=setTimeout(()=>{try{fn();}finally{schedule();}},next-now);};schedule();return()=>timer&&clearTimeout(timer);
}
export function createIntervalScheduler(fn,ms){const t=setInterval(fn,ms);return()=>clearInterval(t);}
