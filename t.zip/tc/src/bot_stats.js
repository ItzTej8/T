import { atomicWriteJson } from './platform_core.js';
import fs from 'node:fs';
import path from 'node:path';
import { dataDir } from './platform_core.js';

const FILE = path.join(dataDir, 'bot-stats.json');
const DEFAULTS = {
  startedAt: Date.now(),
  commands: 0,
  tracksPlayed: 0,
  reconnects: 0,
  voiceRecoveries: 0,
  voiceFailures: 0,
  lastTrack: '',
  lastRoom: ''
};

function load() {
  try {
    if (fs.existsSync(FILE)) return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
  } catch {}
  return { ...DEFAULTS };
}
let stats = load();
let saveTimer=null; function save() { if(saveTimer)return; saveTimer=setTimeout(()=>{saveTimer=null;try{atomicWriteJson(FILE,stats)}catch{}},200); saveTimer.unref?.(); }

export function increment(key, amount = 1) {
  if (!Object.hasOwn(stats, key) || typeof stats[key] !== 'number') return;
  stats[key] += Number(amount) || 0;
  save();
}
export function setStat(key, value) { stats[key] = value; save(); }
export function flushPersistence() { if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; try { atomicWriteJson(FILE, stats); } catch {} } }
export function getStats() { return { ...stats }; }
export function formatUptime(ms = Date.now() - stats.startedAt) {
  let s = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(s / 86400); s %= 86400;
  const h = Math.floor(s / 3600); s %= 3600;
  const m = Math.floor(s / 60); s %= 60;
  return `${d ? `${d}d ` : ''}${h ? `${h}h ` : ''}${m ? `${m}m ` : ''}${s}s`.trim();
}
