import { atomicWriteJson } from './platform_core.js';
import fs from 'node:fs';
import path from 'node:path';
import { dataDir } from './platform_core.js';

const FILE = path.join(dataDir, 'pro-state.json');
const DEFAULT = {
  queueLimit: 100,
  djMode: false,
  djUsers: [],
  userCommands: {},
  userTracks: {},
  topTracks: {},
  schedules: [],
  transitionSeconds: 0,
  playbackSnapshot: null
};

function load() {
  try { if (fs.existsSync(FILE)) return { ...DEFAULT, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch {}
  return structuredClone(DEFAULT);
}
let state = load();
let saveTimer=null; function save() { if(saveTimer)return; saveTimer=setTimeout(()=>{saveTimer=null;try{atomicWriteJson(FILE,state)}catch{}},200); saveTimer.unref?.(); }
export function flushPersistence() { if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; try { atomicWriteJson(FILE, state); } catch {} } }
export function getProState() { return structuredClone(state); }
export function setQueueLimit(n) { const v = Math.max(1, Math.min(1000, Math.floor(Number(n) || 100))); state.queueLimit = v; save(); return v; }
export function getQueueLimit() { return state.queueLimit; }
export function setDjState(enabled, users = state.djUsers) { state.djMode = !!enabled; state.djUsers = [...new Set(users.map(String))]; save(); return { enabled: state.djMode, users: [...state.djUsers] }; }
export function setDjUsers(users) { state.djUsers = [...new Set(users.map(String).filter(Boolean))]; save(); return [...state.djUsers]; }
export function recordUserCommand(user) { const u = String(user || 'User').toLowerCase(); state.userCommands[u] = (state.userCommands[u] || 0) + 1; save(); }
export function recordUserTrack(user, track) { const u = String(user || 'User').toLowerCase(); state.userTracks[u] = (state.userTracks[u] || 0) + 1; const key = String(track?.url || track?.title || '').slice(0, 500); if (key) { if (!state.topTracks[key]) state.topTracks[key] = { title: track?.title || key, artist: track?.artist || 'YouTube', plays: 0 }; state.topTracks[key].plays += 1; } save(); }
export function topTracks(limit = 10) { return Object.values(state.topTracks).sort((a,b)=>b.plays-a.plays).slice(0, Math.max(1, Number(limit)||10)); }
export function topUsers(limit = 10) { return Object.entries(state.userTracks).sort((a,b)=>b[1]-a[1]).slice(0, Math.max(1, Number(limit)||10)).map(([user,plays])=>({user,plays})); }
export function userStats(user) { const u = String(user || 'User').toLowerCase(); return { user: u, commands: state.userCommands[u] || 0, tracks: state.userTracks[u] || 0 }; }
export function setTransitionSeconds(n) { const v = Math.max(0, Math.min(30, Number(n)||0)); state.transitionSeconds = v; save(); return v; }
export function getTransitionSeconds() { return state.transitionSeconds; }
export function savePlaybackSnapshot(snapshot) { state.playbackSnapshot = snapshot ? structuredClone(snapshot) : null; save(); }
export function getPlaybackSnapshot() { return state.playbackSnapshot ? structuredClone(state.playbackSnapshot) : null; }
export function clearPlaybackSnapshot() { state.playbackSnapshot = null; save(); }
export function addSchedule(item) { state.schedules.push(item); save(); return item; }
export function removeSchedule(id) { const before=state.schedules.length; state.schedules=state.schedules.filter(x=>x.id!==id); save(); return before!==state.schedules.length; }
export function listSchedules() { return structuredClone(state.schedules); }
export function updateSchedules(fn) { state.schedules = fn(structuredClone(state.schedules)); save(); return structuredClone(state.schedules); }
