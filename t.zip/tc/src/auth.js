import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { config, log, debug } from "./config.js";
import { encode, decode } from "./proto.js";
import { atomicWriteJson } from "./platform_core.js";

const SESSION_FILE = path.resolve(process.cwd(), ".session.json");

export function loadSession() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const data = JSON.parse(fs.readFileSync(SESSION_FILE, "utf8"));
      if (data && data.sessionId && data.username) return data;
    }
  } catch {}
  return null;
}

export function saveSession(session) {
  try {
    atomicWriteJson(SESSION_FILE, session);
  } catch {}
}

export function clearSession() {
  try {
    if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE);
  } catch {}
}

export function makeAuthPayload({
  action = config.action || "login",
  username = config.username,
  password = config.password,
  captchaCode = config.captchaCode,
  captchaUrl = config.captchaUrl,
  method = config.method
} = {}) {
  if (!username) throw new Error("Set CHATP_USERNAME in .env first");
  if (!password && action === "login") throw new Error("Set CHATP_PASSWORD in .env first");

  const sid = crypto.randomUUID();

  return {
    type: action,
    username: String(username).trim(),
    password: String(password ?? "").trim(),
    captchaCode: String(captchaCode ?? ""),
    captchaUrl: String(captchaUrl ?? ""),
    sid,
    sdk: String(config.sdk || "35"),
    os: "android@",
    ver: String(config.ver || "444"),
    clientVer: String(config.clientVer || "2"),
    deviceId: String(config.deviceId || "a1b2c3d4e5f67890"),
    deviceModel: String(config.deviceModel || "444$Google-Pixel_6$33"),
    language: String(config.language || "en"),
    method: String(method ?? "")
  };
}

export async function authenticate(options = {}) {
  const action = options.action || config.action || "login";
  const username = options.username || config.username;

  // Check saved session first if forceLogin is not requested
  if (!options.forceLogin && !options.captchaCode) {
    const saved = loadSession();
    if (saved && saved.username === username && saved.sessionId) {
      log(`[AUTH] Using saved session token for user: ${username} (Port: ${saved.server || config.serverPort})`);
      return saved;
    }
  }

  const payload = makeAuthPayload({ ...options, action });
  const url = `${config.authUrl.replace(/\/$/, "")}/api?auth_new`;

  log("[AUTH] POST", url, `(${payload.type} user=${payload.username})`);
  const body = encode("AuthRequest", payload);

  const https = await import("node:https");
  const buf = await new Promise((resolve, reject) => {
    const req = https.default.request(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream",
        "Accept": "application/octet-stream",
        "User-Agent": "ChatP-Android/5.8.3",
        "Content-Length": body.length
      },
      timeout: 10000
    }, res => {
      if (res.statusCode && res.statusCode >= 400) {
        return reject(new Error(`Auth HTTP ${res.statusCode}: ${res.statusMessage}`));
      }
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });

    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("Auth request timed out"));
    });
    req.write(body);
    req.end();
  });

  const result = decode("AuthResult", buf);

  log("[AUTH RESULT]", result.result, result.message ? `(${result.message})` : "");

  if (result.result !== "ok") {
    const msg = result.message || result.result || "Authentication rejected";
    if (String(result.result).toLowerCase().includes("captcha") || result.photoUrl) {
      log(`[AUTH] Captcha URL: ${result.photoUrl}`);
    }
    throw new Error(`LOGIN FAILED: ${msg}`);
  }

  const session = {
    username: payload.username,
    sessionId: result.id,
    userId: result.userId,
    server: result.server || config.serverPort || "5335",
    photoUrl: result.photoUrl || "",
    photoVersion: result.photoVersion || "0",
    rosterVersion: "0",
    enablePing: result.enablePing !== 0,
    timestamp: Date.now()
  };

  saveSession(session);
  return { ...result, ...session };
}

export async function login(options = {}) {
  return authenticate({ ...options, action: "login" });
}

export async function register(options = {}) {
  return authenticate({ ...options, action: "register", forceLogin: true });
}
