import { log } from "./config.js";
import { fetchLyrics } from "./lyrics.js";

export async function executeHostCommand(context, input) {
  const { client, voiceManager, youtubePlayer, config, connectAuthenticated, joinRoom, leaveRoom, applyFilterChange, stopPlaybackSession } = context;
  const changeFilter = applyFilterChange || (async (_reason, change) => change());
  const args = String(input || "").trim().split(/\s+/);
  const cmd = (args.shift() || "").toLowerCase();
  if (!cmd) return;

switch (cmd) {
      case "help":
        console.log(`
Available Host Commands:
  join <room>                           - Join room & request voice stream
  leave                                 - Leave room & disconnect voice
  play <query/url>                      - Play & replace song (keep queue)
  qplay <query/url>                     - Enqueue a song
  playlist <url>                        - Enqueue YouTube playlist
  seek <mm:ss | sec>                    - Seek audio timestamp
  forward [sec] / rewind [sec]          - Fast forward / rewind
  history / replay [1-5]                - View history / replay recent track
  savequeue <name> / loadqueue <number> - Save current queue / load playlist #
  playlists                             - List saved playlists with numbers
  viewplaylist <number>                - View a saved playlist by number
  deleteplaylist <number>              - Delete saved playlist #
  preset <pop|rock|electronic|...>      - Equalizer audio preset
  bassboost <level> / nightcore / 8d    - Audio DSP filters
  quality [highest|high|medium|low]       - YouTube source audio quality (highest by default)
  speed <0.5-2.0> / karaoke             - Tempo & vocal cut (speed restarts at current position)
  filters / hifi / resetfilters         - View, clean, or reset audio filters
  lyrics [query]                        - Fetch lyrics for current/searched song
  autoplay [on|off]                     - Auto-play related recommendations
  skip / pause / resume / stop          - Playback controls
  queue / np / volume <0-100> / mute    - Queue and playback settings
  status                                - View connection & playback status
  say <message>                         - Send a text message to current room
  login [username] [password]           - Restart session with specified credentials
  exit                                  - Disconnect and exit bot
`);
        break;

      case "join":
        if (args.length < 1 || !args[0].trim()) {
          console.log("Usage: join <room_name>");
        } else {
          const room = args[0].trim();
          try {
            await joinRoom(room, args[1] || "");
            console.log(`[CLI] Joined room and started the APK-compatible voice state machine for "${room}".`);
          } catch (err) {
            console.error(`[CLI] Join error: ${err.message}`);
          }
        }
        break;

      case "leave":
        if (client.currentRoom) {
          try { await leaveRoom({ leaveTextRoom: true }); console.log("Left room."); }
          catch (err) { console.error(`[CLI] Leave error: ${err.message}`); }
        } else {
          console.log("Bot is not currently in any room.");
        }
        break;

      case "play":
        if (args.length < 1) {
          console.log("Usage: play <youtube URL or search query>");
        } else {
          try {
            const { track } = await youtubePlayer.replaceAndPlay(args.join(" "), "Host Console");
            console.log(`[CLI] Now playing: "${track.title}" (${track.duration})`);
          } catch (err) {
            console.error(`[CLI] Play error: ${err.message}`);
          }
        }
        break;

      case "qplay":
        if (args.length < 1) {
          console.log("Usage: qplay <youtube URL or search query>");
        } else {
          try {
            const { track, queuePosition } = await youtubePlayer.enqueue(args.join(" "), "Host Console");
            console.log(`[CLI] Queued #${queuePosition}: "${track.title}" (${track.duration})`);
          } catch (err) {
            console.error(`[CLI] Queue error: ${err.message}`);
          }
        }
        break;

      case "playlist":
        if (args.length < 1) {
          console.log("Usage: playlist <playlist_url>");
        } else {
          try {
            const res = await youtubePlayer.enqueuePlaylist(args.join(" "), "Host Console");
            console.log(`[CLI] Enqueued ${res.count} tracks from "${res.playlist.title}" (Total queue: ${res.totalQueue})`);
          } catch (err) {
            console.error(`[CLI] Playlist error: ${err.message}`);
          }
        }
        break;

      case "seek": {
        const str = args[0];
        let sec = Number(str);
        if (str && str.includes(":")) {
          const parts = str.split(":").map(Number);
          sec = parts.length === 2 ? parts[0] * 60 + parts[1] : parts[0] * 3600 + parts[1] * 60 + parts[2];
        }
        if (isNaN(sec)) {
          console.log("Usage: seek <seconds or mm:ss>");
        } else {
          await youtubePlayer.seek(sec);
          console.log(`[CLI] Seeked to: ${youtubePlayer.getProgressBar(10)}`);
        }
        break;
      }

      case "forward":
      case "ff":
        await youtubePlayer.forward(Number(args[0]) || 15);
        console.log(`[CLI] Forwarded: ${youtubePlayer.getProgressBar(10)}`);
        break;

      case "rewind":
      case "rw":
        await youtubePlayer.rewind(Number(args[0]) || 15);
        console.log(`[CLI] Rewound: ${youtubePlayer.getProgressBar(10)}`);
        break;

      case "history":
        console.log("--- Playback History ---");
        youtubePlayer.getRecentHistory().forEach((t, i) => console.log(`${i + 1}. "${t.title}" (${t.duration})`));
        break;

      case "replay":
        await youtubePlayer.replay(Number(args[0]) || 1);
        break;

      case "quality": {
        if (!args[0]) {
          console.log(`Audio quality: ${youtubePlayer.getAudioQuality()} (${youtubePlayer.getAudioQualityFormat()})`);
          break;
        }
        const q = String(args[0]).toLowerCase();
        if (!['highest','high','medium','low'].includes(q)) {
          console.log("Usage: quality <highest|high|medium|low>");
          break;
        }
        const previous = youtubePlayer.getAudioQuality();
        if (q !== previous) {
          try { await changeFilter("audio-quality", () => youtubePlayer.setAudioQuality(q)); }
          catch (err) { youtubePlayer.setAudioQuality(previous); throw err; }
        }
        console.log(`[CLI] Audio quality: ${youtubePlayer.getAudioQuality().toUpperCase()} (${youtubePlayer.getAudioQualityFormat()})`);
        break;
      }

      case "voicefx":
      case "voicepreset": {
        const name = args[0];
        const available = "normal deep helium demon robot radio megaphone underwater alien";
        if (!name) { console.log(`Voice FX: ${voiceManager.filters.voiceFx} | Available: ${available}`); break; }
        const result = await changeFilter("voice-fx", () => voiceManager.setVoiceFx(name));
        console.log(`[CLI] Voice FX: ${result || "Invalid voice FX"}`);
        break;
      }
      case "preset":
      case "eq":
        if (!args[0]) {
          console.log("Usage: preset <pop|rock|electronic|treble|vaporwave|soft|clear>");
        } else {
          const p = await changeFilter("preset", () => voiceManager.setPreset(args[0]));
          console.log(`[CLI] Preset: ${p ? p.toUpperCase() : "Invalid preset"}`);
        }
        break;

      case "savequeue":
        if (!args[0]) {
          console.log("Usage: savequeue <playlist_name>");
        } else {
          try {
            const s = youtubePlayer.saveQueueAsPlaylist(args[0], "Host Console");
            console.log(`[CLI] Saved playlist "${s.name}" with ${s.trackCount} tracks!`);
          } catch (err) {
            console.error(`[CLI] Save error: ${err.message}`);
          }
        }
        break;

      case "loadqueue": {
        const list = youtubePlayer.getSavedPlaylists();
        const n = Number(String(args[0] || "").replace(/^#/, ""));
        if (!Number.isInteger(n) || n < 1 || n > list.length) {
          console.log(`Usage: loadqueue <playlist_number> (1-${list.length})`);
        } else {
          try {
            const l = await youtubePlayer.loadSavedPlaylist(list[n - 1].name, "Host Console");
            console.log(`[CLI] Loaded playlist #${n} "${l.playlist.name}" (${l.count} tracks)!`);
          } catch (err) {
            console.error(`[CLI] Load error: ${err.message}`);
          }
        }
        break;
      }

      case "playlists":
        console.log("--- Saved Playlists ---");
        youtubePlayer.getSavedPlaylists().forEach((p, i) => console.log(`${i + 1}. "${p.name}" (${p.trackCount} tracks)`));
        console.log("Use: loadqueue <number> | viewplaylist <number> | deleteplaylist <number>");
        break;

      case "viewplaylist": {
        const list = youtubePlayer.getSavedPlaylists();
        const n = Number(String(args[0] || "").replace(/^#/, ""));
        if (!Number.isInteger(n) || n < 1 || n > list.length) {
          console.log(`Usage: viewplaylist <playlist_number> (1-${list.length})`);
        } else {
          const p = list[n - 1];
          console.log(`--- Playlist #${n}: "${p.name}" (${p.trackCount} tracks) ---`);
          p.tracks.slice(0, 20).forEach((t, i) => console.log(`${i + 1}. ${t.title} (${t.duration || "?"})`));
        }
        break;
      }

      case "deleteplaylist": {
        const list = youtubePlayer.getSavedPlaylists();
        const n = Number(String(args[0] || "").replace(/^#/, ""));
        if (!Number.isInteger(n) || n < 1 || n > list.length) {
          console.log(`Usage: deleteplaylist <playlist_number> (1-${list.length})`);
        } else {
          const name = list[n - 1].name;
          const ok = youtubePlayer.deleteSavedPlaylist(name);
          console.log(ok ? `[CLI] Deleted playlist #${n} "${name}".` : `[CLI] Playlist not found.`);
        }
        break;
      }

      case "bassboost":
        console.log("Bass Boost:", await changeFilter("bassboost", () => voiceManager.setBassBoost(args[0] || "med")));
        break;

      case "nightcore":
        console.log("Nightcore:", await changeFilter("nightcore", () => voiceManager.setNightcore(args[0] ? args[0] === "on" : !voiceManager.filters.nightcore)));
        break;

      case "treble":
        console.log("Treble:", await changeFilter("treble", () => voiceManager.setTreble(args[0] ?? 0)), "dB");
        break;

      case "8dspeed":
        console.log("8D speed:", await changeFilter("8d-speed", () => voiceManager.setEightDSpeed(args[0] ?? 0.11)), "Hz");
        break;

      case "width":
      case "stereowidth":
        console.log("Stereo width:", await changeFilter("width", () => voiceManager.setStereoWidth(args[0] ?? 0)), "%");
        break;

      case "pitch":
        console.log("Pitch:", await changeFilter("pitch", () => voiceManager.setPitch(args[0] ?? 0)), "semitones");
        break;

      case "nightmode":
        console.log("Night mode:", await changeFilter("nightmode", () => voiceManager.setNightMode(args[0] ? args[0] === "on" : !voiceManager.filters.nightMode)));
        break;

      case "limiter":
        console.log("Limiter:", await changeFilter("limiter", () => voiceManager.setLimiter(args[0] ? args[0] === "on" : !voiceManager.filters.limiter)));
        break;

      case "normalize":
        console.log("Normalize:", await changeFilter("normalize", () => voiceManager.setNormalize(args[0] ? args[0] === "on" : !voiceManager.filters.normalize)));
        break;

      case "chorus":
        console.log("Chorus:", await changeFilter("chorus", () => voiceManager.setChorus(args[0] ? args[0] === "on" : !voiceManager.filters.chorus)));
        break;
      case "flanger":
        console.log("Flanger:", await changeFilter("flanger", () => voiceManager.setFlanger(args[0] ? args[0] === "on" : !voiceManager.filters.flanger)));
        break;
      case "vibrato":
        console.log("Vibrato:", await changeFilter("vibrato", () => voiceManager.setVibrato(args[0] ? args[0] === "on" : !voiceManager.filters.vibrato)));
        break;
      case "crystalizer":
      case "crystallizer":
        console.log("Crystalizer:", await changeFilter("crystalizer", () => voiceManager.setCrystalizer(args[0] ? args[0] === "on" : !voiceManager.filters.crystalizer)));
        break;
      case "haas":
        console.log("Haas:", await changeFilter("haas", () => voiceManager.setHaas(args[0] ? args[0] === "on" : !voiceManager.filters.haas)));
        break;
      case "deesser":
      case "de-esser":
        console.log("De-Esser:", await changeFilter("deesser", () => voiceManager.setDeesser(args[0] ? args[0] === "on" : !voiceManager.filters.deesser)));
        break;
      case "basscut":
        console.log("Bass Cut:", await changeFilter("basscut", () => voiceManager.setBassCut(args[0] ? args[0] === "on" : !voiceManager.filters.bassCut)));
        break;
      case "hifi":
        await changeFilter("hifi", () => { voiceManager.clearFilters(); youtubePlayer.setAudioQuality("highest"); return true; });
        console.log("Hi-Fi: maximum source quality + clean DSP path enabled.");
        break;
      case "fadein":
        console.log("Fade-in:", await changeFilter("fadein", () => voiceManager.setFadeIn(args[0] ? args[0] === "on" : !voiceManager.filters.fadeIn)));
        break;

      case "8d":
        console.log("8D Audio:", await changeFilter("8d", () => voiceManager.setEightD(args[0] ? args[0] === "on" : !voiceManager.filters.eightD)));
        break;

      case "speed":
        console.log("Speed:", await changeFilter("speed", () => voiceManager.setSpeed(args[0] || 1.0)));
        break;

      case "karaoke":
        console.log("Karaoke:", await changeFilter("karaoke", () => voiceManager.setKaraoke(args[0] ? args[0] === "on" : !voiceManager.filters.karaoke)));
        break;

      case "filters":
        console.log("Active Filters:", voiceManager.getFilterSummary());
        break;

      case "resetfilters":
        await changeFilter("reset-filters", () => voiceManager.clearFilters());
        console.log("Filters reset.");
        break;

      case "lyrics": {
        const q = args.join(" ") || youtubePlayer.currentTrack?.title;
        if (q) {
          const res = await fetchLyrics(q);
          console.log(res?.lyrics ? `\n--- Lyrics for ${res.title} ---\n${res.lyrics}\n` : "No lyrics found.");
        }
        break;
      }

      case "autoplay":
        console.log("Autoplay:", youtubePlayer.setAutoplay(args[0] ? args[0] === "on" : !youtubePlayer.autoplay));
        break;

      case "skip":
        youtubePlayer.skip();
        break;

      case "pause":
        youtubePlayer.pause();
        break;

      case "resume":
        youtubePlayer.resume();
        break;

      case "stop":
        if (stopPlaybackSession) await stopPlaybackSession();
        else youtubePlayer.stop();
        break;

      case "queue": {
        const q = youtubePlayer.getQueue();
        const current = youtubePlayer.getNowPlaying();
        console.log("--- Music Queue ---");
        console.log("Now Playing:", current ? `"${current.title}" (${current.duration})` : "None");
        console.log("Upcoming:", q.map((t, i) => `${i + 1}. "${t.title}" (${t.duration})`).join("\n") || "Empty");
        break;
      }

      case "np":
      case "nowplaying": {
        const t = youtubePlayer.getNowPlaying();
        if (t) {
          console.log(`Now Playing: "${t.title}"`);
          console.log(youtubePlayer.getProgressBar(15));
        } else {
          console.log("Nothing currently playing.");
        }
        break;
      }

      case "volume":
      case "vol":
        if (args.length < 1) {
          console.log(`Current volume: ${Math.round(voiceManager.volume * 100)}%`);
        } else {
          const v = parseInt(args[0], 10);
          if (isNaN(v) || v < 0 || v > 100) {
            console.log("Volume must be between 0 and 100.");
          } else {
            voiceManager.setVolume(v / 100);
            console.log(`Volume set to ${v}%`);
          }
        }
        break;

      case "loop":
        try {
          console.log("Loop:", youtubePlayer.setLoop(args[0] || "off"));
        } catch (err) {
          console.log("Usage: loop off|track|queue");
        }
        break;

      case "status":
        console.log("--- Bot Status ---");
        console.log("WebSocket Connected:", client.socket?.connected ?? false);
        console.log("Current Room:", client.currentRoom || "None");
        console.log("LiveKit Voice Connected:", voiceManager.isConnected);
        console.log("Music Playing:", youtubePlayer.isPlaying);
        console.log("Audio Filters:", voiceManager.getFilterSummary());
        console.log("Queue Length:", youtubePlayer.queue.length);
        break;

      case "say":
      case "msg":
        if (args.length < 1) {
          console.log("Usage: say <message>");
        } else if (!client.currentRoom) {
          console.log("Bot is not in a room. Join a room first.");
        } else {
          const text = args.join(" ");
          client.sendRoomText(client.currentRoom, text);
          console.log(`[Sent to ${client.currentRoom}]: ${text}`);
        }
        break;

      case "login":
        if (args.length < 2) {
          console.log("Usage: login <username> <password>");
        } else {
          console.log(`[CLI] Runtime login switching is disabled to prevent orphan WebSocket/session state. Restart the bot with CHATP_USERNAME=${args[0]} and CHATP_PASSWORD set in .env, then run it again.`);
        }
        break;

      case "exit":
      case "quit":
        console.log("Shutting down bot...");
        clearInterval(keepAlive);
        await voiceManager.disconnect();
        client.socket?.close();
        process.exit(0);
        break;

      default:
        // The Ink command center exposes the full room command surface too.
        // If a command is not a host-only action, route it through the same
        // room dispatcher used by chat/voice commands so menu entries really work.
        if (typeof context.sendRoomCommand === "function" && context.client?.currentRoom) {
          await context.sendRoomCommand({
            room: context.client.currentRoom,
            text: input.startsWith(".") ? input : `.${input}`,
            username: context.config?.username || "Host Console",
            userId: context.config?.username || "host-console",
            role: "owner"
          });
        } else {
          console.log(`Unknown command: "${cmd}". Type "help" for available commands.`);
        }
        break;
    }
  return { command: cmd };
}
