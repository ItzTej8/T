import util from 'node:util';

const enabled = !process.env.NO_COLOR && process.env.FORCE_COLOR !== '0';
const ansi = (code, s) => enabled ? `\x1b[${code}m${s}\x1b[0m` : s;
const dim = s => ansi('2', s);
const bold = s => ansi('1', s);
const cyan = s => ansi('36', s);
const green = s => ansi('32', s);
const yellow = s => ansi('33', s);
const red = s => ansi('31', s);
const magenta = s => ansi('35', s);
const blue = s => ansi('34', s);
const white = s => ansi('37', s);
let logSink = null;
let debugEnabled = process.env.CHATP_DEBUG === 'true';
export function setLogSink(fn) { logSink = typeof fn === 'function' ? fn : null; }
export function setDebugEnabled(value) { debugEnabled = Boolean(value); }
export function isDebugEnabled() { return debugEnabled; }


const debugDedup = new Map();
const DEBUG_DEDUP_WINDOW_MS = Math.max(0, Number(process.env.DEBUG_DEDUP_WINDOW_MS || 1000));
function shouldEmitDebug(key) {
  const now = Date.now();
  const prev = debugDedup.get(key) || 0;
  if (DEBUG_DEDUP_WINDOW_MS > 0 && now - prev < DEBUG_DEDUP_WINDOW_MS) return false;
  debugDedup.set(key, now);
  if (debugDedup.size > 500) {
    for (const [k, t] of debugDedup) if (now - t > DEBUG_DEDUP_WINDOW_MS * 4) debugDedup.delete(k);
  }
  return true;
}

const icons = { INFO: '◆', SUCCESS: '✔', WARN: '▲', ERROR: '✖', DEBUG: '•', EVENT: '◇' };
const levelColors = { INFO: cyan, SUCCESS: green, WARN: yellow, ERROR: red, DEBUG: dim, EVENT: magenta };

function time() {
  return new Date().toLocaleTimeString('en-GB', { hour12: false });
}

function cleanArgs(args) {
  return args.map(v => typeof v === 'string' ? v : util.inspect(v, { depth: 4, colors: false, compact: true, breakLength: 140 })).join(' ');
}

function normalizeMessage(text) {
  let value = String(text ?? '').trim();
  const tags = [];
  // Pull all leading bracket tags. This lets the logger own the visual prefix
  // while preserving meaningful event tags in the message body.
  while (true) {
    const m = value.match(/^\[([^\]]+)\]\s*/);
    if (!m) break;
    tags.push(m[1]);
    value = value.slice(m[0].length);
  }
  return { value, tags };
}

function category(text) {
  const { tags } = normalizeMessage(text);
  const meaningful = tags.find(t => !/^(INFO|SUCCESS|WARN|WARNING|ERROR|DEBUG|EVENT)$/i.test(t));
  if (meaningful) return /^EVENT:/i.test(meaningful) ? 'EVENT' : meaningful.toUpperCase();
  return tags.some(t => /^EVENT:/i.test(t)) ? 'EVENT' : 'BOT';
}

function stripOwnedPrefixes(text, cat) {
  let value = String(text ?? '').trim();
  const wanted = String(cat || '').toUpperCase();
  while (true) {
    const m = value.match(/^\[([^\]]+)\]\s*/);
    if (!m) break;
    const tag = m[1];
    if (/^(INFO|SUCCESS|WARN|WARNING|ERROR|DEBUG)$/i.test(tag)) {
      value = value.slice(m[0].length);
      continue;
    }
    if (tag.toUpperCase() === wanted || (wanted === 'EVENT' && /^EVENT:/i.test(tag))) {
      value = value.slice(m[0].length);
      // Keep an EVENT name visible once, but don't repeat it as a category.
      if (wanted === 'EVENT' && /^EVENT:/i.test(tag)) {
        return `${tag.replace(/^EVENT:/i, '')} ${value}`.trim();
      }
      continue;
    }
    break;
  }
  return value;
}

function levelFor(text, requested) {
  if (requested) return requested;
  if (/\[EVENT:/i.test(text)) return 'EVENT';
  if (/\b(error|failed|failure|fatal|timeout|timed out|crash)\b/i.test(text)) return 'ERROR';
  if (/\b(warn|warning|retry|recover|reconnect|stale|deprecated)\b/i.test(text)) return 'WARN';
  if (/\b(success|connected|published|playing|restored|ready|started)\b/i.test(text)) return 'SUCCESS';
  return 'INFO';
}

export function formatLog(...args) {
  const raw = cleanArgs(args);
  const level = levelFor(raw);
  const cat = category(raw);
  const message = stripOwnedPrefixes(raw, cat);
  const paint = levelColors[level] || white;
  const icon = paint(icons[level] || icons.INFO);
  const tag = paint(`[${level.padEnd(7)}]`);
  const catTag = bold(white(`[${cat}]`));
  return `${dim(time())} ${icon} ${tag} ${catTag} ${message}`;
}

export function log(...args) { const line = formatLog(...args); if (logSink) { try { logSink(line); return; } catch {} } process.stdout.write(line + '\n'); }
export function info(...args) { log(...args); }
export function success(...args) { log(...args); }
export function warn(...args) { const line = formatLog('[WARN]', ...args); if (logSink) { try { logSink(line); return; } catch {} } process.stderr.write(line + '\n'); }
export function error(...args) { const line = formatLog('[ERROR]', ...args); if (logSink) { try { logSink(line); return; } catch {} } process.stderr.write(line + '\n'); }
export function debug(...args) { if (debugEnabled) { const raw = cleanArgs(args); if (!shouldEmitDebug(raw)) return; const line = formatLog('[DEBUG]', ...args); if (logSink) { try { logSink(line); return; } catch {} } process.stdout.write(line + '\n'); } }

export function installPrettyConsole() {
  if (globalThis.__tcbotPrettyConsoleInstalled) return;
  globalThis.__tcbotPrettyConsoleInstalled = true;
  const original = { log: console.log.bind(console), info: console.info.bind(console), warn: console.warn.bind(console), error: console.error.bind(console), debug: console.debug.bind(console) };
  globalThis.__tcbotOriginalConsole = original;
  console.log = (...args) => original.log(formatLog(...args));
  console.info = (...args) => original.info(formatLog(...args));
  console.warn = (...args) => original.warn(formatLog('[WARN]', ...args));
  console.error = (...args) => original.error(formatLog('[ERROR]', ...args));
  console.debug = (...args) => { if (debugEnabled) original.debug(formatLog('[DEBUG]', ...args)); };
}

export function banner(title = 'TalkInChat Music Bot') {
  const line = '━'.repeat(66);
  process.stdout.write(`\n${cyan(line)}\n${bold(white('  🎵  ' + title))}\n${cyan(line)}\n`);
}

export const colors = { ansi, dim, bold, cyan, green, yellow, red, magenta, blue, white };
