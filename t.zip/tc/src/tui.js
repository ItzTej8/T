import React, { useEffect, useMemo, useState } from 'react';
import { render, Box, Text, useInput, useApp, useStdout } from 'ink';
import { setLogSink } from './logger.js';
import { executeHostCommand } from './command_runner.js';
import { COMMAND_CATALOG } from './command_catalog.js';

const e = React.createElement;
const ANSI_RE = /\x1B(?:\[[0-?]*[ -\/]*[@-~]|\][^\x07]*(?:\x07|\x1B\\))/g;
const visibleText = s => String(s ?? '').replace(ANSI_RE, '');
const clip = (s, n=54) => { s=visibleText(s); return s.length>n ? s.slice(0,n-1)+'…' : s; };
const fmtTime = sec => { sec=Math.max(0,Number(sec)||0); const m=Math.floor(sec/60), s=Math.floor(sec%60); return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };
const bar = (pos,total,len=28) => { const p=total>0?Math.max(0,Math.min(1,pos/total)):0; const n=Math.round(p*len); return '━'.repeat(n)+'─'.repeat(len-n); };

function Header({state,tab,width}) {
  const inner=Math.max(16,Number(width||80)-4);
  const left=clip('🎵 TALKINCHAT MUSIC BOT',Math.max(20,Math.floor(inner*0.48)));
  const middle=clip(`● ${state.connected?'ONLINE':'OFFLINE'}`,Math.max(10,Math.floor(inner*0.22)));
  const right=clip(`v5.2.16 • ${tab.toUpperCase()}`,Math.max(12,Math.floor(inner*0.30)));
  return e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'cyan',paddingX:1,width,overflow:'hidden'},
    e(Box,{flexDirection:'row',flexGrow:1,minWidth:0,overflow:'hidden'},
      e(Box,{flexGrow:1,minWidth:0},e(Text,{bold:true,color:'cyan'},left)),
      e(Box,{flexGrow:1,minWidth:0,alignItems:'center'},e(Text,{color:state.connected?'green':'red'},middle)),
      e(Box,{flexGrow:1,minWidth:0,alignItems:'flex-end'},e(Text,{color:'magenta'},right))
    ),
    e(Text,{dimColor:true},clip(`${state.room||'No room'}  |  Voice: ${state.voice?'CONNECTED':'DISCONNECTED'}  |  Publisher: ${state.publishing?'ACTIVE':'IDLE'}`,inner))
  );
}
function NowPlaying({state}) { const t=state.nowPlaying; const total=Number(t?.durationSeconds)||0; return e(Box,{flexDirection:'column',flexGrow:1,flexBasis:0,minWidth:0,borderStyle:'round',borderColor:'magenta',paddingX:1},e(Text,{bold:true,color:'magenta'},'NOW PLAYING'),e(Text,{color:'yellow'},t?`🎶 ${clip(t.title,43)}`:'Nothing playing'),e(Text,{dimColor:true},t?`${fmtTime(state.elapsed)} / ${fmtTime(total)}`:'—'),e(Text,{color:'cyan'},t?bar(state.elapsed,total):'─'.repeat(28)),e(Text,{dimColor:true},t?`Requested by ${clip(t.requestedBy||'unknown',30)}`:'Ready')) }
function Voice({state}) { const r=state.recovery||{}; const h=state.health||{}; const frameAge=h.lastFrameAt?Math.max(0,Math.round((Date.now()-Number(h.lastFrameAt))/1000)):null; const pcm=h.ffmpeg&&frameAge!==null&&frameAge<12?'HEALTHY':h.ffmpeg?'BUFFERING':'WAITING'; return e(Box,{flexDirection:'column',flexGrow:1,flexBasis:0,minWidth:0,borderStyle:'round',borderColor:'green',paddingX:1},e(Text,{bold:true,color:'green'},'VOICE / RECOVERY'),e(Text,null,`${state.voice?'✔':'✖'} LiveKit   ${state.voice?'CONNECTED':'OFFLINE'}`),e(Text,null,`${state.publishing?'✔':'○'} Publisher ${state.publishing?'ACTIVE':'IDLE'}`),e(Text,null,`${r.running?'▲':'◆'} Recovery  ${r.running?`attempt ${r.attempt||0}`:'STANDBY'}`),e(Text,{dimColor:true},`Session ${clip(state.session?.id||'—',30)}`),e(Text,{dimColor:true},`PCM ${pcm}${frameAge!==null?` • ${frameAge}s ago`:''}`)); }
function Queue({state}) { return e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'yellow',paddingX:1},e(Text,{bold:true,color:'yellow'},`QUEUE  ${state.queue?.length||0}/${state.queueLimit||'∞'}`),(state.queue||[]).slice(0,7).map((t,i)=>e(Text,{key:i},`${String(i+1).padStart(2,' ')}  ${clip(t.title,62)}`)),!(state.queue||[]).length&&e(Text,{dimColor:true},'Queue empty')); }
function Logs({logs,width}) { const inner=Math.max(16,Number(width||80)-4); return e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'blue',paddingX:1,height:8,width,overflow:'hidden'},e(Text,{bold:true,color:'blue'},'LIVE LOGS'),...logs.slice(-6).map((x,i)=>e(Text,{key:i},clip(x,inner)))); }
function Footer({input,tab,menu,selected,query,busy,width}) {
  const inner=Math.max(16,Number(width||80)-4);
  return e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'gray',paddingX:1,width},
    e(Text,{color:'cyan'},clip(`tcbot:${tab}> ${input}${busy?' ⏳':''}`,inner)),
    e(Text,{dimColor:true},clip(menu
      ? `[↑↓] Select  [Enter] Use  [/] Search  [Esc/M] Close  [1-6] Tabs  [Ctrl+C] Exit`
      : `[1-6] Tabs  [M] Commands  [Space] Pause  [S] Skip  [R] Recover  [N] Now Playing  [Q] Queue  [Enter] Command`,inner))
  );
}

function CommandMenu({query,selected,setSelected,choose}) {
  const q=String(query||'').toLowerCase().trim();
  const flat=COMMAND_CATALOG.flatMap(section=>section.commands.map(command=>({command,group:section.group,icon:section.icon})));
  const filtered=flat.filter(x=>!q||x.command.toLowerCase().includes(q)||x.group.toLowerCase().includes(q));
  const index=Math.max(0,Math.min(selected,Math.max(0,filtered.length-1)));
  const windowSize=14;
  let start=Math.max(0,index-Math.floor(windowSize/2));
  start=Math.min(start,Math.max(0,filtered.length-windowSize));
  const visible=filtered.slice(start,start+windowSize);
  return e(Box,{flexDirection:'column',borderStyle:'double',borderColor:'cyan',paddingX:1,marginTop:0},
    e(Box,{justifyContent:'space-between'},e(Text,{bold:true,color:'cyan'},'⌘ COMMAND CENTER'),e(Text,{dimColor:true},`${index+1}/${filtered.length}`)),
    e(Text,{color:'yellow'},`Search: ${query||'all commands'}`),
    e(Box,{flexDirection:'column',height:16,overflow:'hidden'},...visible.map((item,i)=>{
      const absolute=start+i, active=absolute===index;
      return e(Text,{key:`${item.group}:${item.command}`,color:active?'cyan':undefined,bold:active},clip(`${active?'❯':' '} ${item.icon} ${item.command}  ${active?`— ${item.group}`:''}`, 68));
    })),
    e(Text,{dimColor:true},'↑/↓ select • Enter use • type search • Esc/M close')
  );
}

function safeState(context) {
  try {
    if (context && typeof context.getState === 'function') return context.getState() || {};
    const client=context?.client, voice=context?.voiceManager, player=context?.youtubePlayer;
    const health=voice?.getHealth?.() || {};
    const now=player?.getNowPlaying?.() || null;
    return {
      connected:Boolean(client?.socket?.connected || context?.socket?.connected),
      room:client?.currentRoom || '', voice:Boolean(voice?.isConnected), publishing:Boolean(voice?.publishing),
      nowPlaying:now, elapsed:player?.getElapsedSeconds?.() || 0, queue:player?.getQueue?.() || [],
      queueLimit:player?.queueLimit || 100, youtubePlaying:Boolean(player?.isPlaying), paused:Boolean(player?.isPaused),
      quality:player?.getAudioQuality?.() || 'highest', loop:player?.loopMode || 'off', autoplay:Boolean(player?.autoplay),
      volume:player?.volume ?? 1, speed:player?.playbackRate ?? 1, filters:voice?.getFilterSummary?.() || '',
      health, session:null, recovery:{running:false,attempt:0}
    };
  } catch { return {}; }
}

function App({context}) {
  const {exit}=useApp(); const {stdout}=useStdout();
  const terminalWidth=Math.max(40,Number(stdout?.columns)||80);
  const frameWidth=Math.max(40,terminalWidth-2);
  const [state,setState]=useState(()=>safeState(context)); const [logs,setLogs]=useState([]); const [input,setInput]=useState(''); const [tab,setTab]=useState('overview'); const [busy,setBusy]=useState(false);
  const [menu,setMenu]=useState(false); const [menuQuery,setMenuQuery]=useState(''); const [selected,setSelected]=useState(0);
  useEffect(()=>{ let pending=[]; let flushTimer=null; const flush=()=>{flushTimer=null; if(!pending.length)return; const batch=pending.splice(0,pending.length); setLogs(x=>[...x,...batch].slice(-100));}; const sink=line=>{pending.push(String(line)); if(pending.length>=20) flush(); else if(!flushTimer){flushTimer=setTimeout(flush,50);flushTimer.unref?.();}}; setLogSink(sink); const timer=setInterval(()=>setState(safeState(context)),1200); try{stdout.write('\\x1b[?1049h\\x1b[2J\\x1b[H');}catch{} return ()=>{if(flushTimer)clearTimeout(flushTimer);flush();clearInterval(timer);setLogSink(null); try{stdout.write('\\x1b[?1049l');}catch{}}; },[]);
  const tabs=['overview','voice','player','queue','radio','system'];
  const flatCommands=useMemo(()=>COMMAND_CATALOG.flatMap(section=>section.commands.map(command=>({group:section.group,command}))),[menuQuery]);
  const filtered=useMemo(()=>{const q=menuQuery.toLowerCase().trim(); return flatCommands.filter(x=>!q||x.command.toLowerCase().includes(q));},[flatCommands,menuQuery]);
  const run=async command=>{if(!command.trim()||busy)return;setBusy(true);setLogs(x=>[...x,`◆ [CMD] ${command}`].slice(-100));try{await executeHostCommand({...context,keepAlive:null},command);}catch(err){setLogs(x=>[...x,`✖ [ERROR] ${err.message}`].slice(-100));}finally{setBusy(false);setState(safeState(context));}};
  const choose=()=>{const item=filtered[selected]; if(!item)return; setInput(item.command.replace(/<[^>]+>|\[[^\]]+\]/g,'').replace(/\s+/g,' ').trimEnd() + (/[<\[]/.test(item.command)?' ':'')); setMenu(false); setMenuQuery(''); setSelected(0);};
  useInput((ch,key)=>{
    if(key.ctrl&&ch==='c'){exit();return;}
    if(menu){
      if(key.escape || ch.toLowerCase()==='m'){setMenu(false);setMenuQuery('');setSelected(0);return;}
      if(key.upArrow){setSelected(i=>Math.max(0,i-1));return;}
      if(key.downArrow){setSelected(i=>Math.min(Math.max(0,filtered.length-1),i+1));return;}
      if(key.return){choose();return;}
      if(key.backspace||key.delete){setMenuQuery(x=>x.slice(0,-1));setSelected(0);return;}
      if(ch && !key.ctrl && !key.meta){setMenuQuery(x=>x+ch);setSelected(0);return;}
      return;
    }
    if(key.return){const c=input;setInput('');run(c);return;}
    if(key.backspace||key.delete){setInput(x=>x.slice(0,-1));return;}
    if(key.leftArrow||key.rightArrow||key.upArrow||key.downArrow)return;
    if(!input && ch.toLowerCase()==='m'){setMenu(true);return;}
    if(!input && /^[1-6]$/.test(ch)){setTab(tabs[Number(ch)-1]);return;}
    if(!input&&ch===' '){run(state.youtubePlaying?'pause':'resume');return;}
    if(!input&&ch.toLowerCase()==='s'){run('skip');return;}
    if(!input&&ch.toLowerCase()==='r'){run('recovery');return;}
    if(!input&&ch.toLowerCase()==='n'){run('nowplaying');return;}
    if(!input&&ch.toLowerCase()==='q'){setTab('queue');return;}
    if(ch && !key.ctrl && !key.meta)setInput(x=>x+ch);
  });
  const PlayerPanel=()=>e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'magenta',paddingX:1},
    e(Text,{bold:true,color:'magenta'},'PLAYER'),
    e(Text,null,`Playback: ${state.youtubePlaying?(state.paused?'PAUSED':'PLAYING'):'STOPPED'}  •  Quality: ${state.quality||'highest'}`),
    e(Text,null,`Volume: ${Math.round(Number(state.volume??1)*100)}%  •  Speed: ${Number(state.speed??1).toFixed(2)}x  •  Loop: ${String(state.loop||'off').toUpperCase()}`),
    e(Text,{dimColor:true},`Autoplay: ${state.autoplay?'ON':'OFF'}  •  Filters: ${clip(state.filters||'none',65)}`));
  const RadioPanel=()=>e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'yellow',paddingX:1},
    e(Text,{bold:true,color:'yellow'},'RADIO / QUEUE'),
    e(Text,null,`Queue: ${(state.queue||[]).length}/${state.queueLimit||'∞'}  •  Autoplay: ${state.autoplay?'ON':'OFF'}`),
    e(Text,{dimColor:true},`Queued duration: ${fmtTime((state.queue||[]).reduce((n,t)=>n+Number(t?.durationSeconds||0),0))}`),
    e(Text,{dimColor:true},'Use M for Command Center; Q opens the queue tab.'));
  const SystemPanel=()=>e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'blue',paddingX:1},
    e(Text,{bold:true,color:'blue'},'SYSTEM / HEALTH'),
    e(Text,null,`ChatP: ${state.connected?'CONNECTED':'DISCONNECTED'}  •  LiveKit: ${state.voice?'CONNECTED':'DISCONNECTED'}`),
    e(Text,null,`Publisher: ${state.publishing?'ACTIVE':'IDLE'}  •  PCM: ${state.health?.ffmpeg?'PIPELINE':'WAITING'}`),
    e(Text,{dimColor:true},`Room: ${clip(state.room||'—',55)}`));
  let main;
  if(tab==='queue') main=e(Queue,{state});
  else if(tab==='player') main=e(Box,{flexDirection:'column'},e(PlayerPanel));
  else if(tab==='radio') main=e(Box,{flexDirection:'column'},e(RadioPanel));
  else if(tab==='system') main=e(Box,{flexDirection:'column'},e(SystemPanel));
  else if(tab==='voice') main=e(Box,{flexDirection:'column'},e(Voice,{state}));
  else main=e(Box,{flexDirection:'column',width:frameWidth,overflow:'hidden'},e(Box,{flexDirection:'row',width:frameWidth,overflow:'hidden'},e(NowPlaying,{state}),e(Voice,{state})),e(Queue,{state}));
  return e(Box,{flexDirection:'column',width:frameWidth,overflow:'hidden'},e(Header,{state,tab,width:frameWidth}),menu?e(CommandMenu,{query:menuQuery,selected,setSelected,close:()=>setMenu(false),choose}):main,e(Logs,{logs,width:frameWidth}),e(Footer,{input,tab,menu,selected,query:menuQuery,busy,width:frameWidth}));
}

class TuiErrorBoundary extends React.Component {
  constructor(props){ super(props); this.state={error:null}; }
  static getDerivedStateFromError(error){ return {error}; }
  render(){
    if(this.state.error){
      return e(Box,{flexDirection:'column',borderStyle:'round',borderColor:'red',paddingX:1,alignSelf:'stretch'},
        e(Text,{bold:true,color:'red'},'TUI ERROR (bot continues running)'),
        e(Text,null,clip(this.state.error?.message || this.state.error,68)),
        e(Text,{dimColor:true},'Use BOT_UI=classic to switch to the fallback console.'));
    }
    return this.props.children;
  }
}

export function startInkConsole(context){
  return render(e(TuiErrorBoundary,null,e(App,{context})),{exitOnCtrlC:false,patchConsole:false});
}
