import { atomicWriteJson } from './platform_core.js';
import fs from 'node:fs';
import path from 'node:path';

const FILE = path.resolve(process.cwd(), '.bot-settings.json');
const DEFAULTS = {
  alwaysOn: true,
  autoResume: true,
  welcomeEnabled: true,
  defaultRoom: '',
  player: {
    autoplay: false,
    audioQuality: 'highest',
    loopMode: 'off',
    shuffleEnabled: false,
    queueLimit: 100
  },
  voice: { volume: 1, filters: null },
  radio: {
    enabled: false,
    seedMode: 'hybrid',
    maxQueue: 12,
    avoidRecent: 15,
    sameArtistChance: 0.35,
    sameGenreChance: 0.25,
    moodChance: 0.20,
    relatedChance: 0.20
  },
  automation: { autoDj: false, autoRadio: false, refillThreshold: 3 },
  featureFlags: {}
};

function merge(base, value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return { ...base };
  const out = { ...base, ...value };
  for (const k of Object.keys(base)) {
    if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) out[k] = merge(base[k], value?.[k]);
  }
  return out;
}

export function loadSettings() {
  try {
    if (fs.existsSync(FILE)) return merge(DEFAULTS, JSON.parse(fs.readFileSync(FILE, 'utf8')));
  } catch {}
  return structuredClone(DEFAULTS);
}

export function saveSettings(values = {}) {
  const next = merge(DEFAULTS, { ...loadSettings(), ...values });
  try { atomicWriteJson(FILE, next); } catch {}
  return next;
}

export function updateSettings(patch = {}) { return saveSettings(patch); }
export function getSettingsFile() { return FILE; }
