import { log, debug } from "./config.js";

/**
 * Clean up title string by removing common noise (e.g. (Official Music Video), [Lyrics], 4K, HD, etc.)
 */
function cleanSongTitle(rawTitle) {
  return String(rawTitle || "")
    .replace(/\((official\s*(music\s*)?video|lyrics|audio|visualizer|hd|4k|remix|feat\.?.*?)\)/gi, "")
    .replace(/\[(official\s*(music\s*)?video|lyrics|audio|visualizer|hd|4k|remix|feat\.?.*?)\]/gi, "")
    .replace(/\|\s*.*$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Fetch lyrics from open LRCLIB API with automatic title cleanup
 */
export async function fetchLyrics(title, artist = "", durationSeconds = 0) {
  if (!title) return null;

  const cleanedTitle = cleanSongTitle(title);
  const cleanArtist = artist && artist !== "YouTube" ? artist.replace(/\s*-\s*Topic$/i, "").trim() : "";

  // Attempt 1: Direct match query if artist is known
  if (cleanArtist && durationSeconds > 0) {
    try {
      const u = new URL("https://lrclib.net/api/get");
      u.searchParams.set("track_name", cleanedTitle);
      u.searchParams.set("artist_name", cleanArtist);
      u.searchParams.set("duration", String(Math.round(durationSeconds)));
      
      const res = await fetch(u.toString(), {
        headers: { "User-Agent": "ChatP-Music-Bot/1.0" },
        signal: AbortSignal.timeout(5000)
      });
      if (res.ok) {
        const data = await res.json();
        const lyrics = data.plainLyrics || data.syncedLyrics;
        if (lyrics) {
          return {
            title: data.trackName || cleanedTitle,
            artist: data.artistName || cleanArtist,
            lyrics: lyrics.replace(/\[\d{2}:\d{2}\.\d{2}\]\s*/g, "").trim(),
            source: "LRCLIB"
          };
        }
      }
    } catch (e) {
      debug("[Lyrics direct lookup failed]", e.message);
    }
  }

  // Attempt 2: Search endpoint
  try {
    const q = cleanArtist ? `${cleanedTitle} ${cleanArtist}` : cleanedTitle;
    const u = new URL("https://lrclib.net/api/search");
    u.searchParams.set("q", q);

    const res = await fetch(u.toString(), {
      headers: { "User-Agent": "ChatP-Music-Bot/1.0" },
      signal: AbortSignal.timeout(6000)
    });
    if (res.ok) {
      const list = await res.json();
      if (Array.isArray(list) && list.length > 0) {
        const item = list.find(x => x.plainLyrics || x.syncedLyrics) || list[0];
        const lyrics = item.plainLyrics || item.syncedLyrics;
        if (lyrics) {
          return {
            title: item.trackName || cleanedTitle,
            artist: item.artistName || cleanArtist,
            lyrics: lyrics.replace(/\[\d{2}:\d{2}\.\d{2}\]\s*/g, "").trim(),
            source: "LRCLIB"
          };
        }
      }
    }
  } catch (e) {
    debug("[Lyrics search failed]", e.message);
  }

  return null;
}
