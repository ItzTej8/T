import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";

function existsExecutable(p) {
  try { return !!p && fs.existsSync(p) && fs.statSync(p).isFile(); } catch { return false; }
}

function commandPath(cmd) {
  try {
    const resolver = process.platform === "win32" ? "where.exe" : "which";
    const out = execFileSync(resolver, [cmd], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
    return out.split(/\r?\n/).find(Boolean) || null;
  } catch { return null; }
}

function windowsCandidates() {
  const home = os.homedir();
  const local = process.env.LOCALAPPDATA || path.join(home, "AppData", "Local");
  const programData = process.env.ProgramData || "C:\\ProgramData";
  const pf = process.env.ProgramFiles || "C:\\Program Files";
  const pf86 = process.env["ProgramFiles(x86)"] || "C:\\Program Files (x86)";
  const list = [
    path.join(local, "Microsoft", "WinGet", "Links", "ffmpeg.exe"),
    path.join(programData, "chocolatey", "bin", "ffmpeg.exe"),
    path.join(pf, "ffmpeg", "bin", "ffmpeg.exe"),
    path.join(pf86, "ffmpeg", "bin", "ffmpeg.exe"),
    "C:\\ffmpeg\\bin\\ffmpeg.exe"
  ];
  // WinGet often installs into a versioned package directory and updates the
  // PATH only after a new terminal is opened. Discover it immediately.
  const roots = [
    path.join(local, "Microsoft", "WinGet", "Packages"),
    path.join(local, "Microsoft", "WinGet", "Links")
  ];
  for (const root of roots) {
    try {
      if (!fs.existsSync(root)) continue;
      const stack = [root];
      while (stack.length) {
        const dir = stack.pop();
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const full = path.join(dir, entry.name);
          if (entry.isDirectory()) stack.push(full);
          else if (/^ffmpeg\.exe$/i.test(entry.name)) list.push(full);
        }
      }
    } catch {}
  }
  return list;
}

function unixCandidates() {
  const home = os.homedir();
  return [
    process.env.PREFIX ? path.join(process.env.PREFIX, "bin", "ffmpeg") : null,
    "/data/data/com.termux/files/usr/bin/ffmpeg",
    "/usr/bin/ffmpeg",
    "/usr/local/bin/ffmpeg",
    path.join(home, ".local", "bin", "ffmpeg")
  ].filter(Boolean);
}

export function findFfmpeg() {
  const envCandidates = [process.env.FFMPEG_PATH, process.env.FFMPEG, process.env.FFMPEG_BIN];
  for (const p of envCandidates) if (existsExecutable(p)) return p;

  const fromPath = commandPath("ffmpeg");
  if (existsExecutable(fromPath)) return fromPath;

  const candidates = process.platform === "win32" ? windowsCandidates() : unixCandidates();
  for (const p of candidates) if (existsExecutable(p)) return p;
  return null;
}

export function requireFfmpeg() {
  const found = findFfmpeg();
  if (found) return found;
  const platformHint = (process.platform === "android" || process.env.TERMUX_VERSION || process.env.PREFIX?.includes("com.termux"))
    ? "Termux: pkg update -y && pkg install -y ffmpeg"
    : process.platform === "win32"
      ? "Windows: winget install --id Gyan.FFmpeg -e, then reopen the terminal"
      : process.platform === "darwin"
        ? "macOS: brew install ffmpeg"
        : "Linux/Debian: sudo apt-get update && sudo apt-get install -y ffmpeg";
  throw new Error(`FFmpeg is required but was not found. ${platformHint}`);
}
