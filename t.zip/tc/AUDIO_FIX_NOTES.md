# TalkinChat Music Bot v5.2.11 — audio repair

This build fixes the LiveKit music publishing path.

## Important fixes

- LiveKit audio bitrate is now configured through `audioEncoding.maxBitrate` instead of the unsupported `audioBitrate` property.
- Default music bitrate is 510000 bps (510 kbps), the documented maximum-quality stereo Opus target.
- DTX is disabled for continuous music.
- RED is disabled for the high-quality music profile.
- Publishing is explicitly non-simulcast audio.
- Audio remains 48 kHz, stereo, signed 16-bit PCM.
- Every 10 ms frame is copied into an independent, correctly-sized `Int16Array` before entering the LiveKit native FFI layer.
- PCM frame count/health reporting is corrected.
- FFmpeg remains locked to 48 kHz stereo s16le at the raw PCM boundary.

## Environment

Default:

`LIVEKIT_AUDIO_BITRATE=510000`

For a lower-bandwidth test, use 256000 or 128000, but leave 510000 for the highest-quality test.

## Run

1. Extract this ZIP into a clean directory.
2. Do not copy old `node_modules` into it.
3. Run `npm install`.
4. Run `npm start`.

If the stream still produces static/error-like audio after this build, capture the complete `[Voice]` log from connection through the first 5 seconds of `.play`; that log will distinguish FFmpeg/PCM failure from LiveKit/RTP/Android playback failure.
