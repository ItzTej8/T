$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$major = [int]((node -p "process.versions.node.split('.')[0]") 2>$null)
if ($LASTEXITCODE -ne 0 -or $major -lt 18) {
  Write-Host 'Node.js 18+ LTS is required.' -ForegroundColor Yellow
  Write-Host 'Install the current LTS from https://nodejs.org/ and reopen PowerShell.'
  exit 1
}
$env:npm_config_registry = 'https://registry.npmjs.org/'
npm install --include=optional --no-audit --no-fund --prefer-online --fetch-retries=5
if ($LASTEXITCODE -ne 0) { throw 'npm install failed. Run: npm cache verify; npm install --verbose' }
node scripts/platform-start.mjs --setup-only
