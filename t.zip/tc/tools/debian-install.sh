#!/usr/bin/env bash
set -e
sudo apt-get update
sudo apt-get install -y nodejs npm ffmpeg
npm install
npm start
