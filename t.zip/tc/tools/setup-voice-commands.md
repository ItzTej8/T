# Voice Commands

The bot can listen to remote LiveKit audio tracks and turn spoken commands into normal bot commands.

Enable:

```env
VOICE_COMMANDS_ENABLED=true
WHISPER_BIN=whisper
WHISPER_MODEL=base
VOICE_COMMAND_LANGUAGE=auto
```

The bot expects a local Whisper-compatible CLI. The command must accept a WAV input and support `--output_format txt` and `--output_dir` (the standard `whisper` CLI does).

Supported examples:

- “Hey bot, pause”
- “Resume”
- “Skip”
- “Play Blinding Lights”
- “Queue Summer Mix”
- “Volume 70”
- “Volume up”
- “Mute” / “Unmute”
- “8D on” / “8D off”
- “Speed 1.25”
- “What is playing?”
- “Queue”
- “Lyrics”
- “Favorite this”
- “Autoplay on”
- “Rejoin voice”
- “Voice health”

Voice commands use the same command authorization checks as typed commands. Voice audio is processed locally by the configured Whisper executable; no audio is uploaded by this module.

For privacy and CPU usage, the feature is disabled unless `VOICE_COMMANDS_ENABLED=true`.
