#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

pkg update -y
pkg install -y nodejs proot-distro git

echo ""
echo "[Termux] Installing/starting Debian voice environment..."
echo "[Termux] The bot will use Debian for LiveKit native compatibility."

if ! proot-distro list | grep -qi '^.*debian.*installed'; then
  proot-distro install debian
fi

# Keep the project in Termux HOME. The bot's npm start command will enter Debian automatically.
npm start
