#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
pkg update -y
pkg install -y proot-distro
if ! proot-distro list | grep -qi 'debian.*installed'; then proot-distro install debian; fi
node scripts/platform-start.mjs --setup-only
