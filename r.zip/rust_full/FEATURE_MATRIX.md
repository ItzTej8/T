# Rust 5.3 Feature Matrix

## Persistence / recovery
1 Welcome persistence
2 AutoDJ persistence
3 Radio persistence
4 Auto-resume
5 24/7 state
6 Volume persistence
7 Quality persistence
8 Loop persistence
9 Shuffle persistence
10 Queue-limit persistence
11 Voice-FX persistence
12 Speed persistence
13 Pitch persistence
14 8D persistence
15 Room persistence
16 Queue snapshot
17 Current-track snapshot
18 Playback-position snapshot field
19 Recent-history persistence
20 Atomic state writes
21 Crash-safe temp-file replacement
22 Reconnect-safe state restoration
23 Single-flight publisher state
24 Server-streaming state separate from LiveKit state
25 Recovery generation tracking

## Smart playback
26 Smart AutoDJ
27 Hybrid discovery
28 Artist discovery
29 Genre discovery
30 Mood discovery
31 Related discovery
32 Recommended discovery
33 Recent-track avoidance
34 Artist weighting
35 Metadata weighting
36 Genre weighting
37 Mood weighting
38 Duplicate suppression
39 Queue refill threshold
40 Explicit Radio seed
41 Radio independent of current title
42 Multi-result Radio queueing
43 Queue limit enforcement
44 Manual play
45 Queue play
46 Next
47 Skip alias
48 Loop track
49 Loop queue
50 Auto refill

## Voice / audio
51 48 kHz output
52 Stereo output
53 10 ms PCM frames
54 510 kbps target
55 LiveKit native source
56 LiveKit track publication
57 Publisher single-flight
58 Voice reconnect
59 Server directory confirmation
60 Server directory warning when not confirmed
61 Man voice
62 Lady voice
63 Kid boy voice
64 Kid girl voice
65 Old man voice
66 Old woman voice
67 Deep voice
68 Helium voice
69 Demon voice
70 Robot FX
71 Radio FX
72 Telephone FX
73 Megaphone FX
74 Underwater FX
75 Alien FX
76 Ghost FX
77 Cave FX
78 Space FX
79 Walkie FX
80 Vintage FX
81 Child FX
82 Giant FX
83 Glitch FX
84 Cyber FX
85 Vinyl FX
86 Distorted FX
87 Dream FX
88 Dark-hall FX
89 Bass boost
90 Treble
91 Nightcore
92 8D
93 Wide stereo
94 Mono
95 Echo
96 Reverb
97 Lo-fi
98 Chorus
99 Flanger
100 Tremolo
101 Phaser
102 Compressor
103 Limiter
104 Normalize
105 Karaoke
106 Crystalizer
107 Haas
108 De-esser
109 Bass cut
110 Fade-in

## Operations / UX
111 Structured tracing logs
112 ANSI terminal logs
113 Ratatui dashboard
114 Status command
115 Help command
116 Save/persist command
117 Voice FX catalog
118 Environment configuration
119 Windows support
120 Linux support
121 Termux/Linux support
