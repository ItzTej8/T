# TalkInChat Music Bot 5.3.0 — Rust

Rust implementation of the v5.3 Node feature set, with persistent state, Smart AutoDJ, Smart Radio, LiveKit audio publishing, ChatP protobuf messages, voice FX, recovery and a Ratatui terminal dashboard.

## Core guarantees
- Atomic persistent state in `.talkinchat/state.json`.
- Settings are not reset on reconnect or restart.
- Room profile + global settings + playback queue + FX + AutoDJ/Radio state are restored.
- Smart AutoDJ deliberately avoids using the complete current title as its only search seed.
- Discovery modes: `hybrid`, `artist`, `genre`, `mood`, `related`, `recommended`.
- Radio uses its own explicit seed and does not accidentally inherit the current track query.
- Voice publishing is single-flight and recovery-safe.
- ChatP streaming-directory events are tracked separately from LiveKit health; LiveKit success alone is never reported as Voice-tab confirmation.
- 48 kHz stereo signed 16-bit PCM, 10 ms frames, 510 kbps target.
- 70+ audio/voice FX presets and controls.
- Beautiful structured logs + optional full-screen Ratatui TUI.

## Run
Install `yt-dlp` and `ffmpeg`, copy `.env.example` to `.env`, fill credentials, then:

```text
cargo run --release
```

Commands are entered in the terminal or sent to the configured TalkinChat room with `.` prefix.
